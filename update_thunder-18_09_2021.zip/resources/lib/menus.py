# -*- coding: utf-8 -*-
import six
from kodi_six import xbmc, xbmcvfs, xbmcgui, xbmcplugin, xbmcaddon
from resources.lib import control, navigator,language as lang
try:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
except ImportError:    
    from urlparse import urlparse, parse_qs #python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode
try:
    import json
except:
    import simplejson as json
import re
import sys
import os
handle = int(sys.argv[1])

def home():
    xbmcplugin.setContent(handle, 'videos')
    control.item({'name':'[B]'+lang.id('movies')+'[/B]','action': 'movies', 'mediatype': 'video', 'iconimage': control.icon_movies})
    control.item({'name':'[B]'+lang.id('tv_shows')+'[/B]','action': 'tv_shows', 'mediatype': 'video', 'iconimage': control.icon_tvshows})
    control.item({'name':'[B]'+lang.id('animes')+'[/B]','action': 'animes', 'mediatype': 'video', 'iconimage': control.icon_animes})
    control.item({'name':'[B]'+lang.id('live_tv')+'[/B]','action': 'live_tv', 'mediatype': 'video', 'iconimage': control.icon_live_tv})    
    control.item({'name':'[B]'+lang.id('tools')+'[/B]','action': 'tools', 'mediatype': 'video', 'iconimage': control.icon_tools})
    xbmcplugin.endOfDirectory(handle)
    
def movies():
    xbmcplugin.setContent(handle, 'videos')
    control.item({'name':'[B]'+lang.id('premiere')+'[/B]','action': 'premiere_movies', 'mediatype': 'video', 'iconimage': control.icon_premiere})
    control.item({'name':'[B]'+lang.id('trending')+'[/B]','action': 'trending_movies', 'mediatype': 'video', 'iconimage': control.icon_trending})
    control.item({'name':'[B]'+lang.id('search')+'[/B]','action': 'search_movies', 'mediatype': 'video', 'iconimage': control.icon_search})
    xbmcplugin.endOfDirectory(handle)
    
def tv_shows():
    xbmcplugin.setContent(handle, 'videos')
    control.item({'name':'[B]'+lang.id('premiere2')+'[/B]','action': 'premiere_tv_shows', 'mediatype': 'video', 'iconimage': control.icon_premiere})
    control.item({'name':'[B]'+lang.id('trending')+'[/B]','action': 'trending_tv_shows', 'mediatype': 'video', 'iconimage': control.icon_trending})
    control.item({'name':'[B]'+lang.id('new_episodes')+'[/B]','action': 'new_episodes', 'mediatype': 'video', 'iconimage': control.icon_new_episodes})
    control.item({'name':'[B]'+lang.id('search')+'[/B]','action': 'search_tv_shows', 'mediatype': 'video', 'iconimage': control.icon_search})
    xbmcplugin.endOfDirectory(handle)

def live_tv():
    xbmcplugin.setContent(handle, 'videos')
    control.item({'name':'[B]Pluto TV[/B]','action': 'playlist', 'url': 'https://zoreu.inrupt.net/public/pluto.txt', 'mediatype': 'video', 'iconimage': 'https://i.imgur.com/JSs5V3b.png'})
    control.item({'name':'[B]Brazil[/B]','action': 'live_channels_brazil', 'mediatype': 'video', 'iconimage': control.icon_live_tv})
    control.item({'name':'[B]Brazil 2[/B]','action': 'live_channels_brazil2', 'mediatype': 'video', 'iconimage': control.icon_live_tv})
    control.item({'name':'[B]USA[/B]','action': 'live_channels_usa', 'mediatype': 'video', 'iconimage': control.icon_live_tv})
    xbmcplugin.endOfDirectory(handle)

def animes():
    xbmcplugin.setContent(handle, 'videos')
    control.item({'name':'[B]'+lang.id('animes_list')+'[/B]','action': 'animes_list', 'mediatype': 'video', 'iconimage': control.icon_animes})
    control.item({'name':'[B]'+lang.id('search')+'[/B]','action': 'search_animes', 'mediatype': 'video', 'iconimage': control.icon_search})
    xbmcplugin.endOfDirectory(handle)
    
def tools():
    xbmcplugin.setContent(handle, 'videos')
    control.item({'name':'[B]Link Tester (Resolve Url)[/B]','action': 'link_tester', 'mediatype': 'video', 'iconimage': ''})
    control.item({'name':'[B]Resolve Url[/B]','action': 'resolveurl', 'mediatype': 'video', 'iconimage': control.icon_resolveurl})
    control.item({'name':'[B]Manual update[/B]','action': 'update', 'mediatype': 'video', 'iconimage': ''})
    xbmcplugin.endOfDirectory(handle)
       
    
    
def movies_premiere(page):
    url = 'https://api.themoviedb.org/3/movie/now_playing?api_key=7461cdca6387c3a5e6be0d5a8ef7ad2b&append_to_response=external_ids&language=pt-BR&page=%s'%str(page)
    try:
        data = navigator.open_url(url,referer='https://api.themoviedb.org')
        r = json.loads(data)
        total_pages = r.get('total_pages')
        results = r.get('results')
    except:
        total_pages = 0
        results = False
    if results:
        total_items = len(results)
        for item in results:       
            id = item.get('id')
            name = item.get('title')
            original_name = item.get('original_title')
            release = item.get('release_date')
            if release:
                year = release.split('-')[0]
                year = str(year)
            else:
                release = 'false'
                year = '0'
            description = item.get('overview')
            if not description:
                description = ''
            backdrop_path = item.get('backdrop_path')
            search1 = name
            search2 = original_name
            if backdrop_path:
                fanart = 'https://www.themoviedb.org/t/p/original%s'%backdrop_path
            else:
                fanart = ''
            poster_path = item.get('poster_path')
            if poster_path:
                iconimage = 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2%s'%poster_path
            else:
                iconimage = '' 
            if backdrop_path and poster_path and id and name and original_name:
                if not year == '0':
                    new_name = '%s (%s)'%(name,year)
                else:
                    new_name = name
                duration,genre,imdbnumber = open_movie(id)
                try:
                    description = description.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    search1 = search1.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    search2 = search2.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    genre = genre.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    name = name.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    original_name = original_name.encode('utf-8', 'ignore')
                except:
                    pass
                control.item({'name': new_name.encode('utf-8', 'ignore'),'action': 'provider', 'iconimage': iconimage, 'fanart': fanart, 'description': description, 'search1': search1, 'search2': search2, 'aired': release, 'duration': duration, 'genre': genre, 'imdbnumber': imdbnumber, 'codec': 'H264', 'video_title': name, 'originaltitle': original_name, 'year': year, 'mediatype': 'movie'},folder=True)
    else:
        total_items = 0        
    return total_pages,total_items
            
        
def pagination_movies_premiere(page):
    next_page = str(int(page) + 1)
    xbmcplugin.setContent(handle, 'movies')
    total_pages,total_items = movies_premiere(page)
    if int(page) <= total_pages and total_items > 0 and total_pages > 1:
        control.item({'name':'[B]'+lang.id('next')+' '+next_page+' '+lang.id('of')+' '+str(total_pages)+'[/B]','action': 'premiere_movies', 'iconimage': control.icon_next, 'page': next_page, 'mediatype': 'movie'})
    if total_items > 0:
        xbmcplugin.endOfDirectory(handle)
        

def movies_trending(page):
    url = 'https://api.themoviedb.org/3/movie/popular?api_key=7461cdca6387c3a5e6be0d5a8ef7ad2b&append_to_response=external_ids&language=pt-BR&page=%s'%str(page)
    try:
        data = navigator.open_url(url,referer='https://api.themoviedb.org')
        r = json.loads(data)
        total_pages = r.get('total_pages')
        results = r.get('results')
    except:
        total_pages = 0
        results = False
    if results:
        total_items = len(results)
        for item in results:       
            id = item.get('id')
            name = item.get('title')
            original_name = item.get('original_title')
            release = item.get('release_date')
            if release:
                year = release.split('-')[0]
                year = str(year)
            else:
                release = 'false'
                year = '0'
            description = item.get('overview')
            if not description:
                description = ''
            backdrop_path = item.get('backdrop_path')
            search1 = name
            search2 = original_name
            if backdrop_path:
                fanart = 'https://www.themoviedb.org/t/p/original%s'%backdrop_path
            else:
                fanart = ''
            poster_path = item.get('poster_path')
            if poster_path:
                iconimage = 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2%s'%poster_path
            else:
                iconimage = ''               
            if backdrop_path and poster_path and id and name and original_name:
                if not year == '0':
                    new_name = '%s (%s)'%(name,year)
                else:
                    new_name = name             
                duration,genre,imdbnumber = open_movie(id)
                try:
                    description = description.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    search1 = search1.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    search2 = search2.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    genre = genre.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    name = name.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    original_name = original_name.encode('utf-8', 'ignore')
                except:
                    pass
                control.item({'name': new_name.encode('utf-8', 'ignore'), 'action': 'provider', 'iconimage': iconimage,'fanart': fanart,'description': description, 'search1': search1, 'search2': search2, 'aired': release, 'duration': duration, 'genre': genre, 'imdbnumber': imdbnumber, 'codec': 'H264', 'video_title': name, 'originaltitle': original_name, 'year': year, 'mediatype': 'movie'},folder=True)
    else:
        total_items = 0        
    return total_pages,total_items        
     

def pagination_movies_trending(page):
    next_page = str(int(page) + 1)
    xbmcplugin.setContent(handle, 'movies')
    total_pages,total_items = movies_trending(page)
    if int(page) <= total_pages and total_items > 0 and total_pages > 1:
        control.item({'name':'[B]'+lang.id('next')+' '+next_page+' '+lang.id('of')+' '+str(total_pages)+'[/B]','action': 'trending_movies', 'iconimage': control.icon_next, 'page': next_page, 'mediatype': 'movie'})
    if total_items > 0:
        xbmcplugin.endOfDirectory(handle)


def open_movie(id):
    url = 'https://api.themoviedb.org/3/movie/%s?api_key=7461cdca6387c3a5e6be0d5a8ef7ad2b&append_to_response=external_ids&language=pt-BR'%str(id)
    data = navigator.open_url(url,referer='https://api.themoviedb.org')
    try:
        r = json.loads(data)
        imdb_id = r.get('imdb_id')
        runtime = r.get('runtime')
        genres = r.get('genres')
        external_ids = r.get('external_ids')
        if external_ids:
            imdb_external = external_ids.get('imdb_id')
        else:
            imdb_external = 'false'            
        if runtime:
            runtime = runtime*60
        else:
            runtime = 0
        try:
            runtime = str(runtime)
        except:
            pass
        if genres:
            genres = []
            for genre in r['genres']:
                genres.append(genre['name']+' /')
            genres[-1]=genres[-1].replace(' /', '')
            genres = ' '.join(genres)
        else:
            genres = ''
        if imdb_id:
            imdb_id = imdb_id
        else:
            imdb_id = imdb_external
    except:
        runtime = 'false'
        genres = 'false'
        imdb_id = 'false'
    return runtime,genres,imdb_id   
    
def search_movies(search,page):
    url = 'https://api.themoviedb.org/3/search/movie?api_key=7461cdca6387c3a5e6be0d5a8ef7ad2b&query=%s&language=pt-BR&append_to_response=origin_country&page=%s'%(str(search),str(page))
    try:
        data = navigator.open_url(url,referer='https://api.themoviedb.org')
        r = json.loads(data)
        total_pages = r.get('total_pages')
        results = r.get('results')
    except:
        total_pages = 0
        results = False
    if results:
        total_items = len(results)
        for item in results:       
            id = item.get('id')
            name = item.get('title')
            original_name = item.get('original_title')
            release = item.get('release_date')
            if release:
                year = release.split('-')[0]
                year = str(year)
            else:
                release = 'false'
                year = '0'
            description = item.get('overview')
            if not description:
                description = ''
            backdrop_path = item.get('backdrop_path')
            search1 = name
            search2 = original_name
            if backdrop_path:
                fanart = 'https://www.themoviedb.org/t/p/original%s'%backdrop_path
            else:
                fanart = ''
            poster_path = item.get('poster_path')
            if poster_path:
                iconimage = 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2%s'%poster_path
            else:
                iconimage = ''           
            if backdrop_path and poster_path and id and name and original_name:
                if not year == '0':
                    new_name = '%s (%s)'%(name,year)
                else:
                    new_name = name            
                duration,genre,imdbnumber = open_movie(id)
                try:
                    description = description.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    search1 = search1.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    search2 = search2.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    genre = genre.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    name = name.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    original_name = original_name.encode('utf-8', 'ignore')
                except:
                    pass
                control.item({'name': new_name.encode('utf-8', 'ignore'),'action': 'provider', 'iconimage': iconimage, 'fanart': fanart, 'description': description, 'search1': search1, 'search2': search2, 'aired': release, 'duration': duration, 'genre': genre, 'imdbnumber': imdbnumber, 'codec': 'H264', 'video_title': name, 'originaltitle': original_name, 'year': year, 'mediatype': 'movie'},folder=True)
    else:
        total_items = 0        
    return total_pages,total_items     


def pagination_search_movies(search,page):
    next_page = str(int(page) + 1)
    xbmcplugin.setContent(handle, 'movies')
    total_pages,total_items = search_movies(search,page)
    if int(page) <= total_pages and total_items > 0 and total_pages > 1:
        control.item({'name':'[B]'+lang.id('next')+' '+next_page+' '+lang.id('of')+' '+str(total_pages)+'[/B]','action': 'search_movies', 'iconimage': control.icon_next, 'page': next_page, 'search3': str(search), 'mediatype': 'movie'})
    if total_items > 0:
        xbmcplugin.endOfDirectory(handle)
    else:
        control.infoDialog(lang.id('nothing_found'), iconimage='INFO')
        
def tv_shows_premiere(page):
    year_datetime, date = control.get_date()
    url = 'https://api.themoviedb.org/3/discover/tv?api_key=7461cdca6387c3a5e6be0d5a8ef7ad2b&sort_by=popularity.desc&first_air_date_year={}&timezone=America%2FNew_York&include_null_first_air_ates=false&language=pt-BR&page={}'.format(str(year_datetime),str(page))
    try:
        data = navigator.open_url(url,referer='https://api.themoviedb.org')
        r = json.loads(data)
        total_pages = r.get('total_pages')
        results = r.get('results')
    except:
        total_pages = 0
        results = False
    if results:
        total_items = len(results)
        for item in results:         
            id = item.get('id')
            name = item.get('name')
            original_name = item.get('original_name')
            description = item.get('overview')
            if not description:
                description = ''
            backdrop_path = item.get('backdrop_path')
            if backdrop_path:
                fanart = 'https://www.themoviedb.org/t/p/original%s'%backdrop_path
            else:
                fanart = ''
            poster_path = item.get('poster_path')
            if poster_path:
                iconimage = 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2%s'%poster_path
            else:
                iconimage = ''
            release = item.get('first_air_date')
            if release:
                year = release.split('-')[0]
                year = str(year)
            else:
                release = 'false'
                year = '0'
            if backdrop_path and poster_path and id and name and original_name:
                if not year == '0':
                    new_name = '%s (%s)'%(name,year)
                else:
                    new_name = name 
                control.item({'name': new_name.encode('utf-8', 'ignore'),'action': 'season_tvshow', 'iconimage': iconimage, 'fanart': fanart, 'description': description.encode('utf-8', 'ignore'), 'aired': release, 'codec': 'H264', 'video_title': name.encode('utf-8', 'ignore'), 'originaltitle': original_name.encode('utf-8', 'ignore'), 'video_id': id, 'year': year, 'mediatype': 'tvshow'},folder=True)
    else:
        total_items = 0        
    return total_pages,total_items

def pagination_tv_shows_premiere(page):
    next_page = str(int(page) + 1)
    xbmcplugin.setContent(handle, 'tvshows')
    total_pages,total_items = tv_shows_premiere(page)
    if int(page) <= total_pages and total_items > 0 and total_pages > 1:
        control.item({'name':'[B]'+lang.id('next')+' '+next_page+' '+lang.id('of')+' '+str(total_pages)+'[/B]','action': 'premiere_tv_shows', 'iconimage': control.icon_next, 'page': next_page, 'mediatype': 'tvshow'})
    if total_items > 0:
        xbmcplugin.endOfDirectory(handle)    
                
   
def tv_show_trending(page):
    url = 'https://api.themoviedb.org/3/tv/popular?api_key=7461cdca6387c3a5e6be0d5a8ef7ad2b&language=pt-BR&page=%s'%(str(page))
    try:
        data = navigator.open_url(url,referer='https://api.themoviedb.org')
        r = json.loads(data)
        total_pages = r.get('total_pages')
        results = r.get('results')
    except:
        total_pages = 0
        results = False
    if results:
        total_items = len(results)
        for item in results:         
            id = item.get('id')
            name = item.get('name')
            original_name = item.get('original_name')
            description = item.get('overview')
            if not description:
                description = ''
            backdrop_path = item.get('backdrop_path')
            if backdrop_path:
                fanart = 'https://www.themoviedb.org/t/p/original%s'%backdrop_path
            else:
                fanart = ''
            poster_path = item.get('poster_path')
            if poster_path:
                iconimage = 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2%s'%poster_path
            else:
                iconimage = ''
            release = item.get('first_air_date')
            if release:
                year = release.split('-')[0]
                year = str(year)
            else:
                release = 'false'
                year = '0'
            if backdrop_path and poster_path and id and name and original_name:
                if not year == '0':
                    new_name = '%s (%s)'%(name,year)
                else:
                    new_name = name
                control.item({'name': new_name.encode('utf-8', 'ignore'),'action': 'season_tvshow', 'iconimage': iconimage, 'fanart': fanart, 'description': description.encode('utf-8', 'ignore'), 'aired': release, 'codec': 'H264', 'video_title': name.encode('utf-8', 'ignore'), 'originaltitle': original_name.encode('utf-8', 'ignore'), 'video_id': id, 'year': year, 'mediatype': 'tvshow'},folder=True)
    else:
        total_items = 0        
    return total_pages,total_items
    
def pagination_tv_shows_trending(page):
    next_page = str(int(page) + 1)
    xbmcplugin.setContent(handle, 'tvshows')
    total_pages,total_items = tv_show_trending(page)
    if int(page) <= total_pages and total_items > 0 and total_pages > 1:
        control.item({'name':'[B]'+lang.id('next')+' '+next_page+' '+lang.id('of')+' '+str(total_pages)+'[/B]','action': 'trending_tv_shows', 'iconimage': control.icon_next, 'page': next_page, 'mediatype': 'tvshow'})
    if total_items > 0:
        xbmcplugin.endOfDirectory(handle)

def season_tvshow(video_title,originaltitle,year,id):
    xbmcplugin.setContent(handle, 'tvshows')
    url = 'https://api.themoviedb.org/3/tv/%s?api_key=7461cdca6387c3a5e6be0d5a8ef7ad2b&language=pt-BR&append_to_response=external_ids'%str(id)
    data = navigator.open_url(url,referer='https://api.themoviedb.org')
    try:
        r = json.loads(data)
    except:
        r = {}
    backdrop_path = r.get('backdrop_path')
    if backdrop_path:
        fanart = 'https://www.themoviedb.org/t/p/original%s'%backdrop_path
    else:
        fanart = ''
    runtime = r.get('episode_run_time')
    if runtime:
        runtime = runtime[0]*60
    else:
        runtime = 0
    try:
        runtime = str(runtime)
    except:
        pass
    #release = r.get('first_air_date')
    #if release:
    #    year = release.split('-')[0]
    #    year = str(year)
    #else:
    #    release = 'false'
    #    year = '0'
    genres = r.get('genres')
    id = str(id)
    if genres:
        genres = []
        for genre in r['genres']:
            genres.append(genre['name']+' /')
        genres[-1]=genres[-1].replace(' /', '')
        genres = ' '.join(genres)
    else:
        genres = 'false'
    external_ids = r.get('external_ids')             
    if external_ids:
        imdb_external = external_ids.get('imdb_id')
    else:
        imdb_external = 'false'            
    seasons = r.get('seasons')
    if seasons:
        for item in seasons:
            release2 = item.get('air_date')
            if not release2:
                release2 = 'false'
            name = item.get('name')
            description = item.get('overview')
            if not description:
                description = ''
            poster_path = item.get('poster_path')
            if poster_path:
                iconimage = 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2%s'%poster_path
            else:
                iconimage = ''
            season = item.get('season_number')            
            if season and name and not imdb_external == 'false':
                try:
                    description = description.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    video_title = video_title.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    originaltitle = originaltitle.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    genres = genres.encode('utf-8', 'ignore')
                except:
                    pass
                control.item({'name': name.encode('utf-8', 'ignore'),'action': 'episode_tvshow', 'iconimage': iconimage, 'fanart': fanart, 'description': description, 'search1': video_title, 'search2': originaltitle, 'aired': release2, 'duration': runtime, 'genre': genres, 'imdbnumber': imdb_external, 'video_title': video_title, 'originaltitle': originaltitle, 'year': year, 'video_id': id, 'season': season, 'codec': 'H264', 'mediatype': 'season'},folder=True)
        xbmcplugin.endOfDirectory(handle)
    
def episode_tvshow(video_title,originaltitle,genre,imdb,year,duration,id,season,iconimage,fanart):
    xbmcplugin.setContent(handle, 'episodes')
    year_datetime, fulldate = control.get_date()
    url = 'https://api.themoviedb.org/3/tv/{}/season/{}?api_key=7461cdca6387c3a5e6be0d5a8ef7ad2b&language=pt-BR&append_to_response=external_ids'.format(str(id),str(season))
    data = navigator.open_url(url,referer='https://api.themoviedb.org')
    try:
        r = json.loads(data)
    except:
        r = {}
    episodes = r.get('episodes')
    if episodes:
        for item in episodes:
            air_date = item.get('air_date')
            if not air_date:
                release = 'false'
            else:
                release = air_date
            episode = item.get('episode_number')
            if episode:
                episode = str(episode)
            else:
                episode = 'false'
            if air_date:
                fulldate = fulldate.replace('-', '')
                air = air_date.replace('-', '')
                if int(air) > int(fulldate):
                    episode_avaliable = False
                else:
                    episode_avaliable = True
            else:
                episode_avaliable = False                
            name = item.get('name')
            description = item.get('overview')
            if not description:
                description = '' 
            if int(season) < 10:
                sdesc = '0%s'%str(season)
            else:
                sdesc = str(season)
            if int(episode) < 10:
                edesc = '0%s'%str(episode)
            else:
                edesc = str(episode)                
            if name and not episode_avaliable:
                name = 'S%sE%s - %s'%(sdesc,edesc,name)
                name = '[COLOR red]'+name+'[/COLOR]'
            else:
                name = 'S%sE%s - %s'%(sdesc,edesc,name)
            if episode and name and not episode == 'false':
                desc, icon = open_episode(id,season,episode)
                if description == '':
                    description = desc
                if icon != '':
                    iconimage = icon
                else:
                    iconimage = ''
                try:
                    description = description.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    video_title = video_title.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    originaltitle = originaltitle.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    genre = genre.encode('utf-8', 'ignore')
                except:
                    pass
                control.item({'name': name.encode('utf-8', 'ignore'),'action': 'provider', 'iconimage': iconimage, 'fanart': fanart, 'description': description, 'search1': video_title, 'search2': originaltitle, 'aired': release, 'duration': duration, 'genre': genre, 'imdbnumber': imdb, 'video_title': video_title, 'originaltitle': originaltitle, 'year': year, 'season': season, 'episode': episode, 'codec': 'H264', 'mediatype': 'episode'},folder=True)
        xbmcplugin.endOfDirectory(handle)

def open_episode(id,season,episode):
    url = 'https://api.themoviedb.org/3/tv/{}/season/{}/episode/{}?api_key=7461cdca6387c3a5e6be0d5a8ef7ad2b&language=pt-BR&append_to_response=external_ids'.format(str(id),str(season),str(episode))
    data = navigator.open_url(url,referer='https://api.themoviedb.org')
    try:
        r = json.loads(data)
    except:
        r = {}
    description = r.get('overview')
    if description:
        desc = description
    else:
        desc = ''
    still_path = r.get('still_path')
    if still_path:
        iconimage = 'https://www.themoviedb.org/t/p/original%s'%still_path
    else:
        iconimage = ''
    return desc,iconimage

def find_tv_show(imdb):
    url = 'https://api.themoviedb.org/3/find/%s?api_key=7461cdca6387c3a5e6be0d5a8ef7ad2b&language=pt-BR&external_source=imdb_id'%str(imdb)
    data = navigator.open_url(url,referer='https://api.themoviedb.org')
    try:
        r = json.loads(data)
    except:
        r = {}
    tv_results = r.get('tv_results')
    if tv_results:
        for item in tv_results:
            original_name = item.get('original_name')
            overview = item.get('overview')
            if overview:
                desc = overview
            else:
                desc = ''
            first_air_date = item.get('first_air_date')
            name = item.get('name')
            poster_path = item.get('poster_path')
            if poster_path:
                iconimage = 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2%s'%poster_path
            else:
                iconimage = ''            
            if original_name and first_air_date and name:
                year = first_air_date.split('-')[0]
                year = str(year)
                search1 = name
                search2 = original_name
            else:
                year = '0'
                search1 = ''
                search2 = ''
                desc = ''
                iconimage = '' 
            break
    else:
        year = '0'
        search1 = ''
        search2 = ''
        desc = ''
        iconimage = '' 
    return year,search1,search2,desc,iconimage
                
       
def get_lastest_episodes(date):
    date = str(date)
    url = 'https://api.tvmaze.com/schedule?date=%s'%date
    data = navigator.open_url(url,referer='https://api.tvmaze.com/')
    try:
        r = json.loads(data)
    except:
        r = []
        
    if r:    
        for item in r:
            show = item.get('show')
            release = item.get('airdate')
            if release:
                tvshow = release.replace('-', '')
                date_system = date.replace('-', '')
                if tvshow == date_system:
                    avaliable = True
                else:
                    avaliable = False                
            else:
                avaliable = False
                release = 'false'
        
            if show:
                externals = show.get('externals')
                if externals:
                    imdb = externals.get('imdb')
                else:
                    imdb = False
                genres = show.get('genres')
                if genres:
                    genres_ = []
                    for genre in genres:
                        genres_.append(genre+' /')
                    genres_[-1]=genres_[-1].replace(' /', '')
                    genres = ' '.join(genres_)
                else:
                    genres = 'false'
                tv_show_name = show.get('name')
                type = show.get('type')
                image = show.get('image')
                if image:
                    iconimage = image.get('original')
                    if not iconimage:
                        iconimage = ''
                else:
                    iconimage = ''
                description = show.get('summary')
                if description:
                    description = control.cleanhtml(description)
                else:
                    description = ''
            else:
                imdb = False
                genres = 'false'
                tv_show_name = False
                type = False
                iconimage = ''
                description = ''
            title = item.get('name')
            season = item.get('season')
            episode = item.get('number')
            runtime = item.get('runtime')
            if runtime:
                runtime = str(int(runtime)*60)
            else:
                runtime = 'false'
            if season:
                if int(season) < 10:
                    sdesc = '0%s'%str(season)
                else:
                    sdesc = str(season)
            else:
                season = 'false'
            if episode:
                if int(episode) < 10:
                    edesc = '0%s'%str(episode)
                else:
                    edesc = str(episode)
            else:
                episode = 'false'
            if imdb and release and tv_show_name and title and avaliable and type == 'Scripted' and not season =='false' and not episode =='false':           
                year,search1,search2,desc,icon = find_tv_show(imdb)
                if desc == '':
                    desc = description
                if icon == '':
                    icon = iconimage
                if year !='0' and search1 !='' and search2 !='':                
                    fullname = '%s - S%sE%s - %s'%(search1,sdesc,edesc,title)
                    control.item({'name': fullname.encode('utf-8', 'ignore'),'action': 'provider', 'iconimage': icon, 'description': desc.encode('utf-8', 'ignore'), 'search1': search1.encode('utf-8', 'ignore'), 'search2': search2.encode('utf-8', 'ignore'), 'aired': release, 'duration': runtime, 'genre': genres.encode('utf-8', 'ignore'), 'imdbnumber': imdb, 'video_title': search1.encode('utf-8', 'ignore'), 'originaltitle': search2.encode('utf-8', 'ignore'), 'year': year, 'season': season, 'episode': episode, 'codec': 'H264', 'mediatype': 'episode'},folder=True)

def new_episodes():
    from datetime import timedelta, date
    date1 = date.today()
    date2 = date1 - timedelta(days = 1)
    date3 = date1 - timedelta(days = 2)
    date4 = date1 - timedelta(days = 3)
    date5 = date1 - timedelta(days = 4)
    xbmcplugin.setContent(handle, 'episodes')
    get_lastest_episodes(date1)
    get_lastest_episodes(date2)
    get_lastest_episodes(date3)
    get_lastest_episodes(date4)
    get_lastest_episodes(date5)
    xbmcplugin.endOfDirectory(handle)


def search_tv_shows(search,page):
    url = 'https://api.themoviedb.org/3/search/tv?api_key=7461cdca6387c3a5e6be0d5a8ef7ad2b&query=%s&language=pt-BR&page=%s'%(str(search),str(page))
    try:
        data = navigator.open_url(url,referer='https://api.themoviedb.org')
        r = json.loads(data)
        total_pages = r.get('total_pages')
        results = r.get('results')
    except:
        total_pages = 0
        results = False
    if results:
        total_items = len(results)
        for item in results:         
            id = item.get('id')
            name = item.get('name')
            original_name = item.get('original_name')
            description = item.get('overview')
            if not description:
                description = ''
            backdrop_path = item.get('backdrop_path')
            if backdrop_path:
                fanart = 'https://www.themoviedb.org/t/p/original%s'%backdrop_path
            else:
                fanart = ''
            poster_path = item.get('poster_path')
            if poster_path:
                iconimage = 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2%s'%poster_path
            else:
                iconimage = ''
            release = item.get('first_air_date')
            if release:
                year = release.split('-')[0]
                year = str(year)
            else:
                release = 'false'
                year = '0'
            if backdrop_path and poster_path and id and name and original_name:
                if not year == '0':
                    new_name = '%s (%s)'%(name,year)
                else:
                    new_name = name
                control.item({'name': new_name.encode('utf-8', 'ignore'),'action': 'season_tvshow', 'iconimage': iconimage, 'fanart': fanart, 'description': description.encode('utf-8', 'ignore'), 'aired': release, 'codec': 'H264', 'video_title': name.encode('utf-8', 'ignore'), 'originaltitle': original_name.encode('utf-8', 'ignore'), 'video_id': id, 'year': year, 'mediatype': 'tvshow'},folder=True)
    else:
        total_items = 0        
    return total_pages,total_items    


def pagination_search_tv_shows(search,page):
    next_page = str(int(page) + 1)
    xbmcplugin.setContent(handle, 'tvshows')
    total_pages,total_items = search_tv_shows(search,page)
    if int(page) <= total_pages and total_items > 0 and total_pages > 1:
        control.item({'name':'[B]'+lang.id('next')+' '+next_page+' '+lang.id('of')+' '+str(total_pages)+'[/B]','action': 'search_tv_shows', 'iconimage': control.icon_next, 'page': next_page, 'search3': str(search), 'mediatype': 'tvshow'})
    if total_items > 0:
        xbmcplugin.endOfDirectory(handle)
    else:
        control.infoDialog(lang.id('nothing_found'), iconimage='INFO')


def live_channels_brazil(page):
    if int(page) == 1:
        url = 'https://www.iptvm3ulist.com/?s=brazil'
    else:
        url = 'https://www.iptvm3ulist.com/page/%s/?s=brazil'%str(page)
    data = navigator.open_url(url,referer='https://www.iptvm3ulist.com/')
    total_pages = re.compile('<span class="pages">.+?of (.*?)</span>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if total_pages:
        total_pages = int(total_pages[0])
    else:
        total_pages = 1
    items = re.compile('<div class="td-module-thumb"><a href="(.*?)" rel="bookmark" class="td-image-wrap" title="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if items:
        total_items = len(items)
        for link, name in items:               
            control.item({'name': name.encode('utf-8', 'ignore'),'action': 'open_live_channels', 'url': link, 'iconimage': '', 'fanart': '', 'mediatype': 'video'},folder=True)
    else:
        total_items = 0
    return total_pages,total_items
    
def pagination_live_channels_brazil(page):
    next_page = str(int(page) + 1)
    xbmcplugin.setContent(handle, 'videos')
    total_pages,total_items = live_channels_brazil(page)
    if int(page) <= total_pages and total_items > 0 and total_pages > 1:
        control.item({'name':'[B]'+lang.id('next')+' '+next_page+' '+lang.id('of')+' '+str(total_pages)+'[/B]','action': 'live_channels_brazil', 'iconimage': control.icon_next, 'page': next_page, 'mediatype': 'video'})
    if total_items > 0:
        xbmcplugin.endOfDirectory(handle)
        

def live_channels_usa(page):
    if int(page) == 1:
        url = 'https://www.iptvm3ulist.com/?s=usa'
    else:
        url = 'https://www.iptvm3ulist.com/page/%s/?s=usa'%str(page)
    data = navigator.open_url(url,referer='https://www.iptvm3ulist.com/')
    total_pages = re.compile('<span class="pages">.+?of (.*?)</span>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if total_pages:
        total_pages = int(total_pages[0])
    else:
        total_pages = 1
    items = re.compile('<div class="td-module-thumb"><a href="(.*?)" rel="bookmark" class="td-image-wrap" title="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if items:
        total_items = len(items)
        for link, name in items:
            control.item({'name': name.encode('utf-8', 'ignore'),'action': 'open_live_channels', 'url': link, 'iconimage': '', 'fanart': '', 'mediatype': 'video'},folder=True)
    else:
        total_items = 0
    return total_pages,total_items
    
def pagination_live_channels_usa(page):
    next_page = str(int(page) + 1)
    xbmcplugin.setContent(handle, 'videos')
    total_pages,total_items = live_channels_usa(page)
    if int(page) <= total_pages and total_items > 0 and total_pages > 1:
        control.item({'name':'[B]'+lang.id('next')+' '+next_page+' '+lang.id('of')+' '+str(total_pages)+'[/B]','action': 'live_channels_usa', 'iconimage': control.icon_next, 'page': next_page, 'mediatype': 'video'})
    if total_items > 0:
        xbmcplugin.endOfDirectory(handle)        

def open_live_channels(url):
    xbmcplugin.setContent(handle, 'videos')
    data = navigator.open_url(url,referer='https://www.iptvm3ulist.com/')
    items = re.compile('<pre>(.*?)</pre>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if items:
        del items[-1]
        count = 0
        for link in items:
            if '.m3u' in link or '.m3u8' in link:
                count += 1
                name = 'Playlist %s'%str(count)
                control.item({'name': name.encode('utf-8', 'ignore'),'action': 'playlist', 'url': link, 'iconimage': '', 'fanart': '', 'mediatype': 'video'},folder=True)
        xbmcplugin.endOfDirectory(handle)
        
def re_me(data, re_patten):
    match = ''
    m = re.search(re_patten, data)
    if m != None:
        match = m.group(1)
    else:
        match = ''
    return match

def playlist(url):
    if six.PY3:
        f4m = xbmcvfs.translatePath('special://home/addons/plugin.video.f4mTester')
    else:
        f4m = xbmc.translatePath('special://home/addons/plugin.video.f4mTester')
    if os.path.exists(f4m)==True:
        f4mtester = True
    else:
        f4mtester = False
    xbmcplugin.setContent(handle, 'videos')
    data = navigator.open_url(url)    
    if re.search("#EXTM3U",data) or re.search("#EXTINF",data):
        content = data.rstrip()
        match1 = re.compile(r'#EXTINF:.+?tvg-logo="(.*?)".+?group-title="(.*?)",(.*?)[\n\r]+([^\r\n]+)').findall(content)
        if match1 !=[]:
            group_list = []
            for thumbnail,cat,channel_name,stream_url in match1:
                if not cat in group_list:
                    group_list.append(cat)
                    try:
                        cat = cat.encode('utf-8', 'ignore')
                    except:
                        pass
                    control.item({'name': cat,'action': 'playlist2', 'url': url, 'mediatype': 'video', 'iconimage': ''})
        elif match1 ==[]:
            match2 = re.compile(r'#EXTINF:(.+?),(.*?)[\n\r]+([^\r\n]+)').findall(content)
            #match2 = sorted(match2)
            group_list = []
            for other,channel_name,stream_url in match2:
                if 'tvg-logo' in other:
                    thumbnail = re_me(other,'tvg-logo=[\'"](.*?)[\'"]')
                    if thumbnail:
                        if thumbnail.startswith('http'):
                            thumbnail = thumbnail
                        else:
                            thumbnail = ''
                    else:
                        thumbnail = ''
                else:
                    thumbnail = ''

                if 'group-title' in other:
                    cat = re_me(other,'group-title=[\'"](.*?)[\'"]')
                else:
                    cat = ''
                if cat > '':
                    if not cat in group_list:
                        group_list.append(cat)
                        try:
                            cat = cat.encode('utf-8', 'ignore')
                        except:
                            pass
                        control.item({'name': cat,'action': 'playlist2', 'url': url, 'mediatype': 'video', 'iconimage': ''})
                else:
                    stream_url = stream_url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
                    if '.m3u8' in stream_url and f4mtester and not 'pluto.tv' in stream_url:
                        stream_url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+quote_plus(str(channel_name))+'&amp;iconImage='+quote_plus(thumbnail)+'&amp;thumbnailImage='+quote_plus(thumbnail)+'&amp;url='+quote_plus(stream_url)
                    elif f4mtester and not '.mp4' in stream_url and not 'pluto.tv' in stream_url:
                        stream_url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name='+quote_plus(str(channel_name))+'&amp;iconImage='+quote_plus(thumbnail)+'&amp;thumbnailImage='+quote_plus(thumbnail)+'&amp;url='+quote_plus(stream_url)
                    try:
                        channel_name = channel_name.encode('utf-8', 'ignore')
                    except:
                        pass
                    control.item({'name':channel_name,'action': 'play2', 'url': stream_url, 'iconimage': thumbnail, 'playable': 'false'},folder=False)
            if match2 ==[]:
                control.infoDialog(lang.id('no_playlist_available'), iconimage='INFO')
        xbmcplugin.endOfDirectory(handle)
    else:
        control.infoDialog(lang.id('no_playlist_available'), iconimage='INFO')
                
                
def playlist2(name,url):
    if six.PY3:
        f4m = xbmcvfs.translatePath('special://home/addons/plugin.video.f4mTester')
    else:
        f4m = xbmc.translatePath('special://home/addons/plugin.video.f4mTester')
    if os.path.exists(f4m)==True:
        f4mtester = True
    else:
        f4mtester = False        
    xbmcplugin.setContent(handle, 'videos')
    data = navigator.open_url(url)
    if re.search("#EXTM3U",data) or re.search("#EXTINF",data):
        content = data.rstrip()
        match1 = re.compile(r'#EXTINF:.+?tvg-logo="(.*?)".+?group-title="(.*?)",(.*?)[\n\r]+([^\r\n]+)').findall(content)
        if match1 !=[]:
            #match1 = sorted(match1)
            group_list = []
            for thumbnail,cat,channel_name,stream_url in match1:
                try:
                    name = name.decode('utf-8')
                except:
                    pass
                if cat == name:
                    stream_url = stream_url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
                    if '.m3u8' in stream_url and f4mtester and not 'pluto.tv' in stream_url:
                        stream_url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+quote_plus(str(channel_name))+'&amp;iconImage='+quote_plus(thumbnail)+'&amp;thumbnailImage='+quote_plus(thumbnail)+'&amp;url='+quote_plus(stream_url)
                    elif f4mtester and not '.mp4' in stream_url and not 'pluto.tv' in stream_url:
                        stream_url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name='+quote_plus(str(channel_name))+'&amp;iconImage='+quote_plus(thumbnail)+'&amp;thumbnailImage='+quote_plus(thumbnail)+'&amp;url='+quote_plus(stream_url)                    
                    try:
                        channel_name = channel_name.encode('utf-8', 'ignore')
                    except:
                        pass
                    control.item({'name':channel_name,'action': 'play2', 'url': stream_url, 'iconimage': thumbnail, 'playable': 'false'},folder=False)
        elif match1 ==[]:
            match2 = re.compile(r'#EXTINF:(.+?),(.*?)[\n\r]+([^\r\n]+)').findall(content)
            #match2 = sorted(match2)
            for other,channel_name,stream_url in match2:
                if 'tvg-logo' in other:
                    thumbnail = re_me(other,'tvg-logo=[\'"](.*?)[\'"]')
                    if thumbnail:
                        if thumbnail.startswith('http'):
                            thumbnail = thumbnail
                        else:
                            thumbnail = ''
                    else:
                        thumbnail = ''
                else:
                    thumbnail = ''

                if 'group-title' in other:
                    cat = re_me(other,'group-title=[\'"](.*?)[\'"]')
                else:
                    cat = ''
                if cat > '':
                    try:
                        name = name.decode('utf-8')
                    except:
                        pass
                    if cat == name:
                        stream_url = stream_url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
                        if '.m3u8' in stream_url and f4mtester and not 'pluto.tv' in stream_url:
                            stream_url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+quote_plus(str(channel_name))+'&amp;iconImage='+quote_plus(thumbnail)+'&amp;thumbnailImage='+quote_plus(thumbnail)+'&amp;url='+quote_plus(stream_url)
                        elif f4mtester and not '.mp4' in stream_url and not 'pluto.tv' in stream_url:
                            stream_url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name='+quote_plus(str(channel_name))+'&amp;iconImage='+quote_plus(thumbnail)+'&amp;thumbnailImage='+quote_plus(thumbnail)+'&amp;url='+quote_plus(stream_url)
                        try:
                            channel_name = channel_name.encode('utf-8', 'ignore')
                        except:
                            pass
                        control.item({'name':channel_name,'action': 'play2', 'url': stream_url, 'iconimage': thumbnail, 'playable': 'false'},folder=False)                        
        xbmcplugin.endOfDirectory(handle)
    else:
        control.infoDialog(lang.id('no_playlist_available'), iconimage='INFO')

def live_channels_brazil2():
    xbmcplugin.setContent(handle, 'videos')
    url = 'https://zoreu.inrupt.net/public/list_ch.txt'
    data = navigator.open_url(url)
    data = data+'\n'
    data = data.replace('\r','\n')
    data = data.replace('\n\n', '\n')
    playlist = re.compile('(.*?)\n', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if playlist:
        count = 0
        for link in playlist:
            if 'http' in link:
                link = link.replace('\n', '')
                count += 1
                name = 'Playlist %s'%str(count)
                control.item({'name': name.encode('utf-8', 'ignore'),'action': 'playlist', 'url': link, 'iconimage': '', 'fanart': '', 'mediatype': 'video'},folder=True)
        xbmcplugin.endOfDirectory(handle)
        
def animes_list(url):
    xbmcplugin.setContent(handle, 'videos')
    if url and url !='' and url !=None:
        page = url
    else:
        page = 'https://kitsu.io/api/edge/anime?page%5Blimit%5D=20&page%5Boffset%5D=0'
    data = navigator.open_url(page)
    try:
        data = json.loads(data)
    except:
        data = {}
    items = data.get('data')
    links = data.get('links')
    if links:
        next = links.get('next')
    else:
        next = False
    if items:
        for item in items:
            id = item.get('id')
            if id:
                id = str(id)
            attributes = item.get('attributes')
            if attributes: 
                release = attributes.get('createdAt')
                if release:
                    release = release.split('T')[0]
                else:
                    release = ''
                synopsis = attributes.get('synopsis')
                if synopsis:
                    desc = synopsis
                else:
                    desc = ''
                #canonicalTitle = attributes.get('canonicalTitle')
                #if canonicalTitle:
                #    name = canonicalTitle
                #else:
                #    name = False
                Title = attributes.get('titles')
                if Title:
                    name = Title.get('en')
                    if not name:
                        name = Title.get('en_us')
                else:
                    name = False                 
                posterImage = attributes.get('posterImage')
                if posterImage:
                    iconimage = posterImage.get('original')
                else:
                    iconimage = ''
                coverImage = attributes.get('coverImage')
                if coverImage:
                    fanart = coverImage.get('original')
                else:
                    fanart = ''
                #max_episodes = attributes.get('episodeCount')
            else:
                name = False
                iconimage = ''
                fanart = ''
                desc = ''
                release = ''
            relationships = item.get('relationships')
            if relationships:
                episodes = relationships.get('episodes')
                if episodes:
                    links = episodes.get('links')
                    page_episodes = links.get('related')
                    page_episodes = page_episodes+'?page%5Blimit%5D=20&page%5Boffset%5D=0'
                else:
                    page_episodes = False
            else:
                page_episodes = False                
            if id and name and page_episodes:
                try:
                    desc = desc.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    name = name.encode('utf-8', 'ignore')
                except:
                    pass
                control.item({'name': name,'action': 'animes_episodes', 'url': page_episodes, 'iconimage': iconimage, 'fanart': fanart, 'description': desc, 'video_title': name, 'mediatype': 'video'},folder=True)
    if next:
        control.item({'name':'[B]'+lang.id('next_page')+'[/B]','action': 'animes_list', 'url': next, 'iconimage': control.icon_next, 'mediatype': 'video'})
    xbmcplugin.endOfDirectory(handle)
    
def animes_episodes(anime_name,url,fanart):
    if url and url !='' and url !=None:
        xbmcplugin.setContent(handle, 'videos')
        data = navigator.open_url(url)
        try:
            data = json.loads(data)
        except:
            data = {}
        items = data.get('data')
        links = data.get('links')
        if links:
            prev = links.get('prev')
            next = links.get('next')
            last = links.get('last')
        else:
            prev = False
            next = False
            last = False
        if items:
            for item in items:
                id = item.get('id')
                attributes = item.get('attributes')
                if attributes:
                    synopsis = attributes.get('synopsis')
                    if synopsis and not synopsis == 'null':
                        desc = synopsis
                    else:
                        desc = ''
                    #canonicalTitle = attributes.get('canonicalTitle')
                    #if canonicalTitle and not canonicalTitle == 'null':
                    #    name = canonicalTitle
                    #else:
                    #    name = ''
                    Title = attributes.get('titles')
                    if Title:
                        name = Title.get('en')
                        if not name:
                            name = Title.get('en_us')
                    else:
                        name = False                    
                    release = attributes.get('airdate')
                    season = attributes.get('seasonNumber')
                    episode = attributes.get('number')
                    thumbnail = attributes.get('thumbnail')
                    if thumbnail:
                        iconimage = thumbnail.get('original')
                    else:
                        iconimage = ''
                else:
                    desc = ''
                    name = ''
                    release = ''
                    iconimage = ''
                    season = False
                    episode = False
                if season:
                    if int(season) < 10:
                        sdesc = '0%s'%str(season)
                    else:
                        sdesc = str(season)
                else:
                    sdesc = False
                if episode:
                    if int(episode) < 10:
                        edesc = '0%s'%str(episode)
                    else:
                        edesc = str(episode)
                else:
                    edesc = False                
                if season and episode and sdesc and edesc:
                    try:
                        desc = desc.encode('utf-8', 'ignore')
                    except:
                        pass
                    try:
                        anime_name = anime_name.encode('utf-8', 'ignore')
                    except:
                        pass
                    if name:
                        name = 'S%sE%s - %s'%(sdesc,edesc,name)
                    else:
                        name = 'S%sE%s'%(sdesc,edesc)
                    try:
                        anime_name = anime_name.encode('utf-8', 'ignore')
                    except:
                        pass
                    control.item({'name': name.encode('utf-8', 'ignore'),'action': 'provider_animes', 'iconimage': iconimage, 'fanart': fanart, 'description': desc, 'aired': release, 'codec': 'H264', 'search1': anime_name, 'video_title': anime_name,  'season': season, 'episode': episode, 'mediatype': 'video'},folder=True)
        if prev:
            control.item({'name':'[B]'+lang.id('previous_page')+'[/B]','action': 'animes_episodes', 'url': prev, 'iconimage': control.icon_back, 'video_title': anime_name, 'mediatype': 'video'})            
        if next:
            control.item({'name':'[B]'+lang.id('next_page')+'[/B]','action': 'animes_episodes', 'url': next, 'iconimage': control.icon_next, 'video_title': anime_name, 'mediatype': 'video'})
        if last:
            control.item({'name':'[B]'+lang.id('last_page')+'[/B]','action': 'animes_episodes', 'url': last, 'iconimage': '', 'video_title': anime_name, 'mediatype': 'video'})            
        xbmcplugin.endOfDirectory(handle)
    
def animes_search(search):
    page = 'https://kitsu.io/api/edge/anime?filter%5Btext%5D%3D'+search
    data = navigator.open_url(page)
    try:
        data = json.loads(data)
    except:
        data = {}
    items = data.get('data')
    links = data.get('links')
    if links:
        next = links.get('next')
    else:
        next = False
    if items:
        for item in items:
            id = item.get('id')
            if id:
                id = str(id)
            attributes = item.get('attributes')
            if attributes: 
                release = attributes.get('createdAt')
                if release:
                    release = release.split('T')[0]
                else:
                    release = ''
                synopsis = attributes.get('synopsis')
                if synopsis:
                    desc = synopsis
                else:
                    desc = ''
                #canonicalTitle = attributes.get('canonicalTitle')
                #if canonicalTitle:
                #    name = canonicalTitle
                #else:
                #    name = False
                Title = attributes.get('titles')
                if Title:
                    name = Title.get('en')
                    if not name:
                        name = Title.get('en_us')
                else:
                    name = False
                posterImage = attributes.get('posterImage')
                if posterImage:
                    iconimage = posterImage.get('original')
                else:
                    iconimage = ''
                coverImage = attributes.get('coverImage')
                if coverImage:
                    fanart = coverImage.get('original')
                else:
                    fanart = ''
                #max_episodes = attributes.get('episodeCount')
            else:
                name = False
                iconimage = ''
                fanart = ''
                desc = ''
                release = ''
            relationships = item.get('relationships')
            if relationships:
                episodes = relationships.get('episodes')
                if episodes:
                    links = episodes.get('links')
                    page_episodes = links.get('related')
                    page_episodes = page_episodes+'?page%5Blimit%5D=20&page%5Boffset%5D=0'
                else:
                    page_episodes = False
            else:
                page_episodes = False                
            if id and name and page_episodes:
                try:
                    desc = desc.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    name = name.encode('utf-8', 'ignore')
                except:
                    pass
                control.item({'name': name,'action': 'animes_episodes', 'url': page_episodes, 'iconimage': iconimage, 'fanart': fanart, 'description': desc, 'video_title': name, 'mediatype': 'video'},folder=True)
    if next:
        control.item({'name':'[B]'+lang.id('next_page')+'[/B]','action': 'animes_list', 'url': next, 'iconimage': control.icon_next, 'mediatype': 'video'})
    xbmcplugin.endOfDirectory(handle)
    
def update():
    url = 'https://raw.githubusercontent.com/zoreu/addon_thunder/main/update.txt'
    data = navigator.open_url(url)
    match = re.compile(r'id="(.*?)".+?rl="(.*?)"',re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if match:
        for id, url in match:
            try:
                name = id.encode('utf-8', 'ignore')
            except:
                pass
            control.item({'name': name, 'action': 'install', 'addon_id': id, 'url': url, 'mediatype': 'video', 'iconimage': ''})
        xbmcplugin.endOfDirectory(handle)
        
def install(id,url):
    special_dir = 'special://home/addons/'+id
    special_packages = 'special://home/addons/packages'
    if six.PY3:
        directory = xbmcvfs.translatePath(special_dir)
        packages = xbmcvfs.translatePath(special_packages)
    else:
        directory = xbmc.translatePath(special_dir)
        packages = xbmc.translatePath(special_packages)        
    if os.path.exists(directory):
        try:
            from resources.lib import downloader, extract
            import ntpath
            filename = ntpath.basename(url)
            dest=os.path.join(packages, filename)
            dp = xbmcgui.DialogProgress()
            if six.PY3:
                dp.create('Downloading '+id+'...','Please wait...')
            else:
                dp.create('Downloading '+id+'...','Please wait...', '', '')
            downloader.download(url,id,dest,dp=dp)
            zip_file = dest
            extract_folder = directory
            if six.PY3:
                dp.create('Extracting '+id+'...','Please wait...')
            else:
                dp.create('Extracting '+id+'...','Please wait...', '', '')
            dp.update(0)
            extract.all(zip_file,extract_folder, dp=dp)
            try:
                os.remove(zip_file)
            except:
                pass
            control.infoDialog('Update completed', iconimage='INFO')
        except:
            control.infoDialog('Error', iconimage='WARNING')
        