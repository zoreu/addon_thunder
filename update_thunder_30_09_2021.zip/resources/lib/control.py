# -*- coding: utf-8 -*-
import six
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import sys
import os
import re
try:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
except ImportError:    
    from urlparse import urlparse, parse_qs #python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode
from resources.lib import navigator, language as lang
try:
    import json
except:
    import simplejson as json

    

plugin = sys.argv[0]
handle = int(sys.argv[1])
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')
if six.PY3:
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    home = xbmcvfs.translatePath(addon.getAddonInfo('path'))
else:
    profile = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
    home = xbmc.translatePath(addon.getAddonInfo('path')).decode('utf-8')    
fanart_default = os.path.join(home, 'fanart.jpg')
favorites = os.path.join(profile, 'favorites.dat')
icon_movies = os.path.join(home, 'resources','media','movies.png')
icon_tvshows = os.path.join(home, 'resources','media','tvshows.png')
icon_premiere = os.path.join(home, 'resources','media','premiere.png')
icon_trending = os.path.join(home, 'resources','media','trending.png')
icon_search = os.path.join(home, 'resources','media','search.png')
icon_new_episodes = os.path.join(home, 'resources','media','new_episodes.png')
icon_next = os.path.join(home, 'resources','media','next.png')
icon_back = os.path.join(home, 'resources','media','back.png')
icon_resolveurl = os.path.join(home, 'resources','media','resolveurl.png')
icon_live_tv = os.path.join(home, 'resources','media','live_tv.png')
icon_animes = os.path.join(home, 'resources','media','animes.png')
icon_tools = os.path.join(home, 'resources','media','tools.png')
icon_settings = os.path.join(home, 'resources','media','settings.png')
dialog = xbmcgui.Dialog()
    

def get_url(params):
    url = '%s?%s'%(plugin, urlencode(params))
    return url

           
def infoDialog(message, heading=addonname, iconimage='', time=3000, sound=False):
    if iconimage == '':
        iconimage = icon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    dialog.notification(heading, message, iconimage, time, sound=sound)


def item(params,folder=True):
    url = get_url(params)
    name = params.get("name")
    if name:
        name = name
    else:
        name = 'Unknow'
    iconimage = params.get("iconimage")
    fanart = params.get("fanart")
    description = params.get("description")
    if description:
        description  = description
    else:
        description = ''
    codec = params.get("codec")
    playable = params.get("playable")
    duration = params.get("duration")
    originaltitle = params.get("originaltitle")
    imdbnumber = params.get("imdbnumber")
    aired = params.get("aired")
    genre = params.get("genre")
    season = params.get("season")
    episode = params.get("episode")
    mediatype = params.get("mediatype")

    if six.PY3:
        li=xbmcgui.ListItem(name)
        if iconimage:
            #li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
            li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    else:
        if not iconimage:
            iconimage = ''
        li = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    if codec and not codec == 'false':
        try:
            li.addStreamInfo('video', { 'codec': codec, 'width' : 1280 })
        except:
            pass
    if duration and not duration == 'false':
        try:
            li.setInfo('video', { 'duration': int(duration) })
        except:
            pass
    if originaltitle and not originaltitle == 'false':
        try:
            li.setInfo('video', { 'originaltitle': str(originaltitle) })
        except:
            pass
    if imdbnumber and not imdbnumber == 'false':
        try:
            li.setInfo('video', { 'imdbnumber': str(imdbnumber) })
        except:
            pass
    if aired and not aired == 'false':
        try:
            li.setInfo('video', { 'aired': str(aired) })
        except:
            pass
    if genre and not genre == 'false':
        try:
            li.setInfo('video', { 'genre': str(genre) })
        except:
            pass
    if season and not season == 'false':
        try:
            li.setInfo('video', { 'season': int(season) })
        except:
            pass
    if episode and not episode == 'false':
        try:
            li.setInfo('video', { 'season': int(episode) })
        except:
            pass
    if mediatype:
        try:
            li.setInfo('video', { 'mediatype': str(mediatype) })
        except:
            pass
        
    if playable and not playable == 'false':
       li.setProperty('IsPlayable', 'true')
    li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    if fanart:
        li.setProperty('fanart_image', fanart)
    else:
        li.setProperty('fanart_image', fanart_default)
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=folder)


def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    if isinstance(text, bytes):
        return text.decode(encoding, errors=errors)
    return text

def get_search_string(heading='', message=''):
    """Ask the user for a search string"""
    search_string = None
    keyboard = xbmc.Keyboard(message, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_string = to_unicode(keyboard.getText())
    return search_string 

    
def search():
    vq = get_search_string(heading=lang.id('enter_search'), message="")        
    if ( not vq ): return False
    title = quote(vq).replace('%20', '+')
    return title
    
def enter_url():
    vq = get_search_string(heading='Your Url', message="")        
    if ( not vq ): return False
    return vq   
    
def get_date():
    try:
        data = navigator.open_url('http://worldtimeapi.org/api/timezone/America/New_York')
        r = json.loads(data)
    except:
        r = {}        
    datetime = r.get('datetime')
    if datetime:
        last_year = datetime.split('-')[0]
        fulldate = datetime.split('T')[0]
        fulldate = str(fulldate)
    else:
        from datetime import date
        date_today = date.today()
        last_year = date_today.year
        fulldate = str(date_today)
    return last_year, fulldate
   
def cleanhtml(raw_html):
  cleanr = re.compile('<.*?>')
  cleantext = re.sub(cleanr, '', raw_html)
  return cleantext
        
    
def play(name,url,iconimage,fanart,description,playable):
    if url and 'plugin' in url:
        xbmc.executebuiltin('RunPlugin(%s)'%url)        
    elif url and not 'plugin' in url:
        if six.PY3:
            li=xbmcgui.ListItem(name, path=url)
            if iconimage:
                #li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
                li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
        else:
            li = xbmcgui.ListItem(name, path=url, iconImage=iconimage, thumbnailImage=iconimage)
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        if not playable == 'false':
            xbmcplugin.setResolvedUrl(handle, True, li)
        else:
            xbmc.Player().play(item=url, listitem=li)