# -*- coding: utf-8 -*-
import six
import sys
import re
import os
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from resources.lib import control, navigator,language as lang
try:
    from urllib.parse import quote, quote_plus, urlparse #python 3
except ImportError:     
    from urllib import quote, quote_plus #python 2
    from urlparse import urlparse  # Python 2
try:
    import json
except:
    import simplejson as json
if six.PY2:
    try:
        reload(sys)
        sys.setdefaultencoding('utf8')
    except:
        pass
handle = int(sys.argv[1])
folder = control.home
#log_file = os.path.join(folder, 'log.txt')

def fix_characters(st):
    try:
        characters = str(st).replace(r'\xc3\x8c', 'Ì').replace(r'\xc3\xac', 'ì').replace(r'\xc3\x88', 'È').replace(r'\xc3\xa8', 'è').replace(r'\xc3\x80', 'À').replace(r'\xc3\xa0', 'Ü').replace(r'\xc3\x9c', 'Ü').replace(r'\xc3\xbc', 'ü').replace(r'\xc3\x84', 'Ä').replace(r'\xc3\xa4', 'ä').replace(r'\xc3\x9b', 'Û').replace(r'\xc3\xbb', 'û').replace(r'\xc3\x9a', 'Ú').replace(r'\xc3\xba', 'ú').replace(r'\xc3\x87', 'Ç').replace(r'\xc3\xa7', 'ç').replace(r'\xc3\x8e', 'Î').replace(r'\xc3\xae', 'î').replace(r'\xc3\x94', 'Ô').replace(r'\xc3\xb4', 'ô').replace(r'\xc3\x93', 'Ó').replace(r'\xc3\xb3', 'ó').replace(r'\xc3\x82', 'Â').replace(r'\xc3\x8d', 'Í').replace(r'\xc3\x8a', 'Ê').replace(r'\xc3\x89', 'É').replace(r'\xc3\xaa', 'ê').replace(r'\xc3\xa9', 'é').replace(r'\xc3\xa2', 'â').replace(r'\xc3\xa3', 'ã').replace(r'\xc3\x83', 'Ã').replace(r'\xc3\xa1','á').replace(r'\xc3\x81', 'Á').replace(r'\xc3\xad','í')
    except:
        characters = st
    return characters

def warezcdn(imdb,season=False,episode=False):
    if season == 'false':
        season = False
    if episode == 'false':
        episode = False
    servers = []
    if season and episode:
        url = 'https://embed.warezcdn.com/serie/%s/%s/%s'%(str(imdb),str(season),str(episode))
        data = navigator.open_url(url,referer='https://embed.warezcdn.com/')
        audio_id = re.compile('<div class="item" data-load-episode-content="(.*?)">.+?<img class="img" src="(.*?)" loading="lazy">.+?<div class="name">(.*?)</div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
        if audio_id !=[]:
            audio = ''
            for id, img, name in audio_id:
                if str(episode) in name:
                    audio += str(id)
                    break
            if audio !='':
                data2 = navigator.open_url('https://embed.warezcdn.net/serieAjax.php',referer='https://embed.warezcdn.com/',post={'getAudios': audio})
                try:
                    json_ = json.loads(data2)
                except:
                    json_ = {}
                lang = []
                try:
                    languages = json_.get('list')
                except:
                    languages = ''
                languages = re.compile("{'id': '(.*?)', 'audio': '(.*?)', 'mixdropStatus': '(.*?)', 'fembedStatus': '(.*?)', 'streamtapeStatus': '(.*?)'}", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(str(languages))
                if not languages:
                    if '{' in data2 and '}' in data2:
                        try:
                            data2 = data3.split('"list":')[1]
                        except:
                            pass
                        languages = re.compile('"(.*?)":{"id":"(.*?)","audio":"(.*?)","mixdropStatus":"(.*?)","fembedStatus":"(.*?)","streamtapeStatus":"(.*?)"}', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(str(data2))
                        languages2 = []
                        for number, id, lg, mixdrop, fembed, streamtape in languages:
                            languages2.append((id,lg,mixdrop,fembed,streamtape))
                else:
                    languages2 = languages                    
                for id, lg, mixdrop, fembed, streamtape in languages2:                  
                    if str(lg) == '1' or str(lg) == 'Original':
                        lg = 'ORIGINAL'
                    elif str(lg) == '2' or str(lg) == 'Dublado':
                        lg  = 'PORTUGUESE'
                    else:
                        lg = 'UNKNOW'
                    if mixdrop == '3':                        
                        url = 'https://embed.warezcdn.net/getPlay.php?id=%s&sv=mixdrop'%str(id)
                        lang.append((lg, url))
                    if fembed == '3':
                        url = 'https://embed.warezcdn.net/getPlay.php?id=%s&sv=fembed'%str(id)
                        lang.append((lg, url))
                    if streamtape == '3':
                        url = 'https://embed.warezcdn.net/getPlay.php?id=%s&sv=streamtape'%str(id)
                        lang.append((lg, url))                        
                for lg, url in lang:
                    player = navigator.open_url(url,referer='https://embed.warezcdn.com/')
                    try:
                        src = re.compile('window.location.href="(.*?)"').findall(player)[0]
                    except:
                        src = ''
                    if src !='':
                        try:
                            sub = src.split('http')[2]
                            sub = 'http%s'%sub
                            try:
                                sub = sub.split('&')[0]
                            except:
                                pass
                            if not '.srt' in sub:
                                sub = 'false'                                            
                        except:
                            sub = 'false'                             
                        try:
                            src = src.split('?')[0]
                        except:
                            pass
                        try:
                            src = src.split('#')[0]
                        except:
                            pass 
                        parsed_uri = urlparse(src)
                        #servername = '| WAREZCDN | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(), lg)
                        servername = '| SITE 1 | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(), lg)
                        servers.append((servername,src,sub))
    else:
        url = 'https://embed.warezcdn.com/filme/%s'%str(imdb)
        data = navigator.open_url(url,referer='https://embed.warezcdn.com/')
        audio_id = re.compile('<div class="selectAudioButton.+?" data-load-hosts="(.*?)">(.*?)</div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
        if audio_id !=[]:
            lang = {}
            for id, lg in audio_id:
                if 'LEGENDADO' in lg:
                    lang[id]='ORIGINAL'
                elif 'DUBLADO' in lg:
                    lang[id]='PORTUGUESE'
            hosts = re.compile('<div class="buttonLoadHost.+?" data-load-embed="(.*?)" data-load-embed-host="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
            if hosts !=[]:
                for id, name in hosts:
                    lg=lang[id]
                    url = 'https://embed.warezcdn.net/getPlay.php?id=%s&sv=%s'%(str(id),name)
                    player = navigator.open_url(url,referer='https://embed.warezcdn.com/')
                    try:
                        src = re.compile('window.location.href="(.*?)"').findall(player)[0]
                    except:
                        src = ''
                    if src !='':
                        try:
                            sub = src.split('http')[2]
                            sub = 'http%s'%sub
                            try:
                                sub = sub.split('&')[0]
                            except:
                                pass
                            if not '.srt' in sub:
                                sub = 'false'                                            
                        except:
                            sub = 'false'                             
                        try:
                            src = src.split('?')[0]
                        except:
                            pass
                        try:
                            src = src.split('#')[0]
                        except:
                            pass 
                        parsed_uri = urlparse(src)
                        #servername = '| WAREZCDN | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(), lg)
                        servername = '| SITE 1 | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(), lg)
                        servers.append((servername,src,sub))
        else:
            hosts = re.compile('<div class="buttonLoadHost.+?" data-load-embed="(.*?)" data-load-embed-host="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
            if hosts !=[]:
                for id, name in hosts:
                    lg = 'ORIGINAL'
                    url = 'https://embed.warezcdn.net/getPlay.php?id=%s&sv=%s'%(str(id),name)
                    player = navigator.open_url(url,referer='https://embed.warezcdn.com/')
                    try:
                        src = re.compile('window.location.href="(.*?)"').findall(player)[0]
                    except:
                        src = ''
                    if src !='':
                        try:
                            sub = src.split('http')[2]
                            sub = 'http%s'%sub
                            try:
                                sub = sub.split('&')[0]
                            except:
                                pass
                            if not '.srt' in sub:
                                sub = 'false'                                            
                        except:
                            sub = 'false'                             
                        try:
                            src = src.split('?')[0]
                        except:
                            pass
                        try:
                            src = src.split('#')[0]
                        except:
                            pass 
                        parsed_uri = urlparse(src)
                        #servername = '| WAREZCDN | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(), lg)
                        servername = '| SITE 1 | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(), lg)
                        servers.append((servername,src,sub))
    return servers 


def vizertv(search,year,season=False,episode=False):
    if season == 'false':
        season = False
    if episode == 'false':
        episode = False
    if 'iCarly, a Reunião' in search:
        icarly2 = True
        try:
            search = search.split(',')[0]
        except:
            pass
    else:
        icarly2 = False
    if 'Matrix Resurrections' in search:
        search = 'Matrix: Resurrections'        
    url = 'https://vizer.tv/pesquisar/%s'%quote(search)
    url_parsed = urlparse(url)
    hostname = '%s://%s'%(url_parsed.scheme,url_parsed.netloc)
    data = navigator.open_url(url,referer='https://vizer.tv/')
    main = re.compile(r'<main.+?id="seriesList">(.*?)</main>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    servers = []
    if main !=[]:
        list_item = re.findall('<a title="Assistir (.*?) online".+?href="(.*?)">', main[0])
        normalize = [(names.lower(),url) for names, url in list_item]
        link = ''
        for name, url in normalize:
            try:
                url = url.split('"')[0]
            except:
                pass
            name = name.replace('&amp;', '&').replace('&#038;', '&')
            if search.lower() in name:
                if len(search.strip()) == len(name.strip()):
                    if 'serie' in url and season and episode:
                        page = '%s://%s/%s'%(url_parsed.scheme,url_parsed.netloc,url)
                        link += page
                        if icarly2 and not 'icarly-online' in page:
                            link = ''
                            continue
                        else:
                            break
                    elif 'filme' in url:
                        page = '%s://%s/%s'%(url_parsed.scheme,url_parsed.netloc,url)
                        link += page
                        break
        if 'filme' in link:
            data2 = navigator.open_url(link,referer='https://vizer.tv/')
            langs = []
            try:
                audio_id = re.findall('videoPlayerBox(.*?);', data2)[-1].replace('(', '').replace(')', '')
                audio_id = json.loads(audio_id)
                audio_id = audio_id.get('list')
                for number in audio_id:
                    if number == '0':
                        #legendado
                        id = audio_id.get(number).get('id')
                        langs.append(('ORIGINAL', id))
                    elif number == '1':
                        #dublado
                        id = audio_id.get(number).get('id')
                        langs.append(('PORTUGUESE', id))
            except:
                pass
            movie_year = re.findall('"dateCreated":"(.*?)"', data2)
            if movie_year:
                try:
                    movie_year = movie_year[0]
                except:
                    movie_year = 0
                if int(year) == int(movie_year):
                    movie_ok = True
                else:
                    movie_ok = False
            else:
                movie_ok = False
            if langs and movie_ok:
                for lang, id in langs:
                    data3 = navigator.open_url('https://vizer.tv/includes/ajax/publicFunctions.php',referer=link,post={'getVideoPlayers': str(id)})
                    try:
                        json_data3 = json.loads(data3)
                    except:
                        json_data3 = ''
                    if json_data3:
                        status = json_data3.get('status')
                        mixdrop = json_data3.get('mixdrop')
                        fembed = json_data3.get('fembed')
                        streamtape = json_data3.get('streamtape')
                        try:
                            if status == 'success' and int(mixdrop) > 1:
                                url_embed = 'https://vizer.tv/embed/getEmbed.php?id={0}&sv=mixdrop'.format(str(id))
                                data4 = navigator.open_url(url_embed,referer=link)
                                getplay = re.compile('<iframe id="player" src="(.*?)".+?></iframe>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data4)
                                if getplay:
                                    url_getplay = hostname + '/embed/' + getplay[0]
                                    data5 = navigator.open_url(url_getplay,referer=url_embed)
                                    server = re.compile('window.location.href="(.*?)";', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data5)
                                    if server:
                                        try:
                                            src = server[0]
                                        except:
                                            src = ''
                                        if src:
                                            try:
                                                sub = src.split('http')[2]
                                                sub = 'http%s'%sub
                                                try:
                                                    sub = sub.split('&')[0]
                                                except:
                                                    pass
                                                if not '.srt' in sub:
                                                    sub = 'false'                                            
                                            except:
                                                sub = 'false' 
                                            try:
                                                src = src.split('?')[0]
                                            except:
                                                pass
                                            try:
                                                src = src.split('#')[0]
                                            except:
                                                pass 
                                            parsed_uri = urlparse(src)
                                            servername = '| SITE 2 | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(), lang)
                                            servers.append((servername,src,sub))          
                        except:
                            pass
                        try:
                            if status == 'success' and int(fembed) > 1:
                                url_embed = 'https://vizer.tv/embed/getEmbed.php?id={0}&sv=fembed'.format(str(id))
                                data4 = navigator.open_url(url_embed,referer=link)
                                getplay = re.compile('<iframe id="player" src="(.*?)".+?></iframe>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data4)
                                if getplay:
                                    url_getplay = hostname + '/embed/' + getplay[0]
                                    data5 = navigator.open_url(url_getplay,referer=url_embed)
                                    server = re.compile('window.location.href="(.*?)";', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data5)
                                    if server:
                                        try:
                                            src = server[0]
                                        except:
                                            src = ''
                                        if src:
                                            try:
                                                sub = src.split('http')[2]
                                                sub = 'http%s'%sub
                                                try:
                                                    sub = sub.split('&')[0]
                                                except:
                                                    pass
                                                if not '.srt' in sub:
                                                    sub = 'false'                                            
                                            except:
                                                sub = 'false' 
                                            try:
                                                src = src.split('?')[0]
                                            except:
                                                pass
                                            try:
                                                src = src.split('#')[0]
                                            except:
                                                pass 
                                            parsed_uri = urlparse(src)
                                            servername = '| SITE 2 | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(), lang)
                                            servers.append((servername,src,sub))          
                        except:
                            pass
                        try:
                            if status == 'success' and int(streamtape) > 1:
                                url_embed = 'https://vizer.tv/embed/getEmbed.php?id={0}&sv=streamtape'.format(str(id))
                                data4 = navigator.open_url(url_embed,referer=link)
                                getplay = re.compile('<iframe id="player" src="(.*?)".+?></iframe>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data4)
                                if getplay:
                                    url_getplay = hostname + '/embed/' + getplay[0]
                                    data5 = navigator.open_url(url_getplay,referer=url_embed)
                                    server = re.compile('window.location.href="(.*?)";', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data5)
                                    if server:
                                        try:
                                            src = server[0]
                                        except:
                                            src = ''
                                        if src:
                                            try:
                                                sub = src.split('http')[2]
                                                sub = 'http%s'%sub
                                                try:
                                                    sub = sub.split('&')[0]
                                                except:
                                                    pass
                                                if not '.srt' in sub:
                                                    sub = 'false'                                            
                                            except:
                                                sub = 'false' 
                                            try:
                                                src = src.split('?')[0]
                                            except:
                                                pass
                                            try:
                                                src = src.split('#')[0]
                                            except:
                                                pass 
                                            parsed_uri = urlparse(src)
                                            servername = '| SITE 2 | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(), lang)
                                            servers.append((servername,src,sub))          
                        except:
                            pass
        elif 'serie' in link:
            data2 = navigator.open_url(link,referer='https://vizer.tv/')
            seasons = re.compile('<div.+?class="item ".+?data-season-id="(.*?)">(.*?)</div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data2)
            tvshow_year = re.findall('<div class="year">(.*?)</div>', data2)
            if tvshow_year:
                try:
                    tvshow_year = tvshow_year[0]
                except:
                    tvshow_year = 0
                if int(year) == int(tvshow_year):
                    tvshow_ok = True
                else:
                    tvshow_ok = False
            else:
                tvshow_ok = False
            season_id = ''
            if seasons:
                for id, season_ in seasons:
                    if int(season) == int(season_):
                        season_id += str(id)
                        break
            if season_id and tvshow_ok == True:
                data3 = navigator.open_url('https://vizer.tv/includes/ajax/publicFunctions.php',referer=link, post={'getEpisodes': str(season_id)})
                try:
                    json_data3 = json.loads(data3)
                except:
                    json_data3 = ''
                if json_data3:
                    episodes = json_data3.get('list')
                    episode_id = ''
                    episode_count = 0
                    for item in episodes:
                        episode_count += 1
                        if int(episode_count) == int(episode):
                            episode_ = episodes.get(item)
                            _id = episode_.get('id')
                            episode_id += str(_id)
                            break
                    if episode_id:
                        data4 = navigator.open_url('https://vizer.tv/includes/ajax/publicFunctions.php',referer=link,post={'getEpisodeLanguages': str(episode_id)})
                        try:
                            json_data4 = json.loads(data4)
                        except:
                            json_data4 = ''
                        langs = []
                        if json_data4:
                            langs_ = json_data4.get('list')
                            if langs_:
                                for item in langs_:
                                    ep_lang = langs_.get(item)
                                    lang_id = ep_lang.get('id')
                                    lg = ep_lang.get('lang')
                                    if lg == '1':
                                        lang = 'ORIGINAL'
                                        langs.append((lang,lang_id))
                                    elif lg == '2':
                                        lang = 'PORTUGUESE'
                                        langs.append((lang,lang_id))
                        if langs:
                            for lang, id in langs:
                                data5 = navigator.open_url('https://vizer.tv/includes/ajax/publicFunctions.php',referer=link,post={'getVideoPlayers': str(id)})
                                try:
                                    json_data5 = json.loads(data5)
                                except:
                                    json_data5 = ''
                                if json_data5:
                                    status = json_data5.get('status')
                                    mixdrop = json_data5.get('mixdrop')
                                    fembed = json_data5.get('fembed')
                                    streamtape = json_data5.get('streamtape')
                                    try:
                                        if status == 'success' and int(mixdrop) > 1:
                                            url_embed = 'https://vizer.tv/embed/getEmbed.php?id={0}&sv=mixdrop'.format(str(id))
                                            data6 = navigator.open_url(url_embed,referer=link)
                                            getplay = re.compile('<iframe id="player" src="(.*?)".+?></iframe>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data6)
                                            if getplay:
                                                url_getplay = hostname + '/embed/' + getplay[0]
                                                data7 = navigator.open_url(url_getplay,referer=url_embed)
                                                server = re.compile('window.location.href="(.*?)";', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data7)
                                                if server:
                                                    try:
                                                        src = server[0]
                                                    except:
                                                        src = ''
                                                    if src:
                                                        try:
                                                            sub = src.split('http')[2]
                                                            sub = 'http%s'%sub
                                                            try:
                                                                sub = sub.split('&')[0]
                                                            except:
                                                                pass
                                                            if not '.srt' in sub:
                                                                sub = 'false'                                            
                                                        except:
                                                            sub = 'false' 
                                                        try:
                                                            src = src.split('?')[0]
                                                        except:
                                                            pass
                                                        try:
                                                            src = src.split('#')[0]
                                                        except:
                                                            pass 
                                                        parsed_uri = urlparse(src)
                                                        servername = '| SITE 2 | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(), lang)
                                                        servers.append((servername,src,sub))          
                                    except:
                                        pass
                                    try:
                                        if status == 'success' and int(fembed) > 1:
                                            url_embed = 'https://vizer.tv/embed/getEmbed.php?id={0}&sv=fembed'.format(str(id))
                                            data6 = navigator.open_url(url_embed,referer=link)
                                            getplay = re.compile('<iframe id="player" src="(.*?)".+?></iframe>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data6)
                                            if getplay:
                                                url_getplay = hostname + '/embed/' + getplay[0]
                                                data7 = navigator.open_url(url_getplay,referer=url_embed)
                                                server = re.compile('window.location.href="(.*?)";', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data7)
                                                if server:
                                                    try:
                                                        src = server[0]
                                                    except:
                                                        src = ''
                                                    if src:
                                                        try:
                                                            sub = src.split('http')[2]
                                                            sub = 'http%s'%sub
                                                            try:
                                                                sub = sub.split('&')[0]
                                                            except:
                                                                pass
                                                            if not '.srt' in sub:
                                                                sub = 'false'                                            
                                                        except:
                                                            sub = 'false' 
                                                        try:
                                                            src = src.split('?')[0]
                                                        except:
                                                            pass
                                                        try:
                                                            src = src.split('#')[0]
                                                        except:
                                                            pass 
                                                        parsed_uri = urlparse(src)
                                                        servername = '| SITE 2 | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(), lang)
                                                        servers.append((servername,src,sub))          
                                    except:
                                        pass
                                    try:
                                        if status == 'success' and int(streamtape) > 1:
                                            url_embed = 'https://vizer.tv/embed/getEmbed.php?id={0}&sv=streamtape'.format(str(id))
                                            data6 = navigator.open_url(url_embed,referer=link)
                                            getplay = re.compile('<iframe id="player" src="(.*?)".+?></iframe>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data6)
                                            if getplay:
                                                url_getplay = hostname + '/embed/' + getplay[0]
                                                data7 = navigator.open_url(url_getplay,referer=url_embed)
                                                server = re.compile('window.location.href="(.*?)";', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data7)
                                                if server:
                                                    try:
                                                        src = server[0]
                                                    except:
                                                        src = ''
                                                    if src:
                                                        try:
                                                            sub = src.split('http')[2]
                                                            sub = 'http%s'%sub
                                                            try:
                                                                sub = sub.split('&')[0]
                                                            except:
                                                                pass
                                                            if not '.srt' in sub:
                                                                sub = 'false'                                            
                                                        except:
                                                            sub = 'false' 
                                                        try:
                                                            src = src.split('?')[0]
                                                        except:
                                                            pass
                                                        try:
                                                            src = src.split('#')[0]
                                                        except:
                                                            pass 
                                                        parsed_uri = urlparse(src)
                                                        servername = '| SITE 2 | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(), lang)
                                                        servers.append((servername,src,sub))          
                                    except:
                                        pass
    return servers

def novovizer_resolve(url):
    if 'novovizer.com' in url and 'trid' in url:
        data = navigator.open_url(url,referer='https://novovizer.com/')
        iframe = re.compile(r'<iframe.+?src="(.*?)".+?></iframe>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
        if iframe:
            source = iframe[0]
            if not 'netutv' in source and not 'gdriveplayer' in source:
                if '/v/' in source:
                    stream = source.replace('/v/', '/stream/720/')
                    stream = stream + '/__001'
                    url = stream + '|Referer=' + source
                else:
                    url = source
            else:
                url = False
        else:
            url = False
    else:
        url = False
    return url

def novovizer(search,year,season=False,episode=False):
    if season == 'false':
        season = False
    if episode == 'false':
        episode = False
    if 'Guerra nas Estrelas' in search:
        search = 'Star Wars - Uma Nova Esperança'
        starwars1 = True
    else:
        starwars1 = False
    if 'The Flash' in search:
        search = search.split('The ')[1]
    url = 'https://novovizer.com/?s=%s'%quote(search).replace('%20', '+')
    data = navigator.open_url(url,referer='https://novovizer.com/')
    list_item = re.findall(r'<h2 class="entry-title">(.*?)</h2>.+?<a href="(.*?)" class="lnk-blk"></a>', data)
    normalize = [(names.lower(),url) for names, url in list_item]
    servers = []
    link = ''
    for name, url in normalize:
        try:
            name = name.split('(')[0]
        except:
            pass
        name = name.replace('&amp;', '&').replace('&#038;', '&')
        if search.lower() in name:
            if len(search.strip()) == len(name.strip()):
                if 'series' in url and season and episode:
                    link += url
                    break
                elif 'movies' in url:
                    link += url
                    break 
    if starwars1 == True and link == '':
        link = 'https://novovizer.com/movies/star-wars-uma-nova-esperanca/'    
    if 'series' in link:
        data2 = navigator.open_url(link,referer='https://novovizer.com/')
        seasons = re.findall('<li class="sel-temp"><a data-post="(.*?)" data-season="(.*?)" href.+?>.+?</a></li>', data2)
        tvshow_year = re.findall(r'<span class="year fa-calendar far">(.*?)</span>', data2)
        if tvshow_year !=[]:
            try:
                tvshow_year = tvshow_year[0]
            except:
                tvshow_year = 0
            if int(year) == int(tvshow_year):
                tvshow_ok = True
            else:
                tvshow_ok = False
        else:
            tvshow_ok = False
        season_id = ''
        season_post = ''
        for id, season_ in seasons:
            if int(season) == int(season_):
                season_id += str(id)
                season_post += str(season_)
                break
        if season_id !='' and season_post !='' and tvshow_ok == True:
            data3 = navigator.open_url('https://novovizer.com/wp-admin/admin-ajax.php',referer='https://novovizer.com/',post={'action': 'action_select_season', 'season': season_post, 'post': season_id})
            episodes = re.findall('<span class="num-epi">.+?x(.*?)</span>.+?<a href="(.*?)" class="lnk-blk"></a>', data3)
            page = ''
            for number, pg in episodes:
                if int(number) == int(episode):
                    page += pg
                    break
            if page !='':
                data4 = navigator.open_url(page,referer='https://novovizer.com/')
                dublado = re.search('<meta property="og:title" content=".+?Dublado.+?" />', data4)
                if dublado:
                    lang = 'PORTUGUESE'
                else:
                    lang = 'ORIGINAL'
                #iframe = re.findall('<iframe.+?data-src="(.*?)".+?</iframe>', data4)
                iframe = re.compile('<iframe.+?data-src="(.*?)".+?</iframe>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data4)
                for server in iframe:
                    server = server.replace('#038;', '')
                    if not 'netutv' in server and not 'gdriveplayer' in server:
                        if 'novovizer.com' in server and 'trid' in server:
                            url = novovizer_resolve(server)
                            if url:
                                if not 'netutv' in url and not 'gdriveplayer' in url:
                                    server = url
                        if 'upvideo' in server or '/stream/' in server or 'streamtape' in server or 'streamlare' in server:
                            if re.search("Dual",server,re.IGNORECASE):
                                lang = 'PORTUGUESE'
                            elif re.search("Legendado",server,re.IGNORECASE):
                                lang = 'ORIGINAL'
                            elif re.search("Leg",server,re.IGNORECASE):
                                lang = 'ORIGINAL'
                            if 'novovizer' in server:
                                sv = server.replace('novovizer', 'site 3')
                            else:
                                sv = server
                            parsed_uri = urlparse(sv)
                            #servername = '| NOVOVIZER | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(),lang)
                            servername = '| SITE 3 | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(),lang)
                            url = server
                            sub = 'false'
                            servers.append((servername,url,sub))            
    elif 'movies' in link:
        data2 = navigator.open_url(link,referer='https://novovizer.com/')
        dublado = re.search('<meta property="og:title" content=".+?Dublado.+?" />', data2)
        movie_year = re.findall(r'<span class="year fa-calendar far">(.*?)</span>', data2)
        if movie_year !=[]:
            try:
                movie_year = movie_year[0]
            except:
                movie_year = 0
            if int(year) == int(movie_year):
                movie_ok = True
            else:
                movie_ok = False
        else:
            movie_ok = False   
        if dublado:
            lang = 'PORTUGUESE'
        else:
            lang = 'ORIGINAL'
        if movie_ok == True:
            #iframe = re.findall('<iframe.+?data-src="(.*?)".+?</iframe>', data2)
            iframe = re.compile('<iframe.+?data-src="(.*?)".+?</iframe>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data2)
            for server in iframe:
                server = server.replace('#038;', '')
                if not 'netutv' in server and not 'gdriveplayer' in server:
                    if 'novovizer.com' in server and 'trid' in server:
                        url = novovizer_resolve(server)
                        if url:
                            if not 'netutv' in url and not 'gdriveplayer' in url:
                                server = url
                    if 'upvideo' in server or '/stream/' in server or 'streamtape' in server or 'streamlare' in server:                                
                        if re.search("Dual",server,re.IGNORECASE):
                            lang = 'PORTUGUESE'
                        elif re.search("Legendado",server,re.IGNORECASE):
                            lang = 'ORIGINAL'
                        elif re.search("Leg",server,re.IGNORECASE):
                            lang = 'ORIGINAL'                    
                        if 'novovizer' in server:
                            sv = server.replace('novovizer', 'site 3')
                        else:
                            sv = server
                        parsed_uri = urlparse(sv)
                        #servername = '| NOVOVIZER | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(),lang)
                        servername = '| SITE 3 | %s | %s'%(parsed_uri.netloc.split('.')[0].upper(),lang)
                        url = server
                        sub = 'false'
                        servers.append((servername,url,sub))        
    return servers

def suatela(search,year,season=False,episode=False):
    search = search.replace("Marvel's", "Marvels")
    if season == 'false':
        season = False
    if episode == 'false':
        episode = False
    if 'Guerra nas Estrelas' in search:
        search = 'Star Wars: Episódio IV - Uma Nova Esperança'        
    url = 'https://suatela.com/buscar/%s'%quote(search)
    url_parsed = urlparse(url)
    protocol = url_parsed.scheme
    netloc = url_parsed.netloc
    referer = 'https://suatela.com/'
    data = navigator.open_url(url,referer=referer)
    main = re.compile(r'<div id="year">(.*?)</div>.+?<div id="title"><h1><a href.+?post.view(.*?),(.*?),(.*?);" title.+?>(.*?)</a></h1></div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    servers = []
    search_id = ''
    for year_search,id,link,bol,title in main:
        title = title.replace('&amp;', '&').replace('&#038;', '&')
        name = title.lower()
        id = id.replace("('",'').replace("'","")
        link = link.replace("'","")
        bol = bol.replace(")","")
        bol = bol.strip()
        if bol == 'true':
            if search.lower() in name:
                if len(search.strip()) == len(name.strip()) and int(year_search) == int(year):
                    if 'serie' in link and season and episode:
                        search_id += id
                        break
                    elif 'filme':
                        search_id += id
                        break
    if search_id !='' and season and episode:
        url = '%s://%s/ajax/view.php?type=loading-post&id=%s'%(protocol,netloc,search_id)
        data2 = navigator.open_url(url,referer=referer)
        try:
            r = json.loads(data2)
        except:
            r = {}
        player = r.get('player')
        max_season = r.get('temporada')
        category = r.get('tipo')
        if player and max_season and category:
            if not int(season) > int(max_season):
                url_list = ['%s://%s/ajax/view.php?type=loading-episode&id=%s&season=%s&audio=dublado&query=2', '%s://%s/ajax/view.php?type=loading-episode&id=%s&season=%s&audio=legendado&query=2']
                lang = []
                for url in url_list:
                    lg = url.split('audio=')[1].split('&')[0]
                    url = url%(protocol,netloc,str(player),str(season))
                    data3 = navigator.open_url(url,referer=referer)
                    try:
                        r = json.loads(data3)
                    except:
                        r = []
                    if r:
                        count = 0
                        for item in r:
                            count += 1
                            id = item.get('id')                             
                            if id and int(episode) == count:
                                lang.append((lg,id))
                                break
                if lang:
                    for lg, id in lang:
                        if lg == 'legendado':
                            lg2 = 'ORIGINAL'
                        else:
                            lg2 = 'PORTUGUESE'
                        url = '%s://%s/ajax/view.php?type=loading-video&id=%s&category=%s&type_video=%s'%(protocol,netloc,str(id),str(category),lg)
                        data4 = navigator.open_url(url,referer=referer)
                        try:
                            r = json.loads(data4)
                        except:
                            r = {}
                        player = r.get('player')
                        if player:
                            link = re.compile('date-url="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(player)
                            if link:
                                try:
                                    link = link[0]
                                    data5 = navigator.open_url(link,referer=referer)
                                except:
                                    data5 = ''
                                quality_1080p = re.compile("<input type='hidden' name='url_download_1080p' id='url_download_1080p' value='(.*?)'>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data5)
                                quality_720p = re.compile("<input type='hidden' name='url_download_720p' id='url_download_720p' value='(.*?)'>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data5)
                                quality_480p = re.compile("<input type='hidden' name='url_download_480p' id='url_download_480p' value='(.*?)'>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data5)
                                subtitle = re.compile("<input type='hidden' name='legenda_download' id='legenda_download' value='(.*?)'>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data5)
                                if 'http' in str(quality_1080p) or '/' in str(quality_1080p):
                                    src = quality_1080p[0]
                                elif 'http' in str(quality_720p) or '/' in str(quality_720p):
                                    src = quality_720p[0]
                                elif 'http' in str(quality_480p) or '/' in str(quality_480p):
                                    src = quality_480p[0]
                                else:
                                    src = 'false'                                     
                                if '.srt' in src:
                                    if not src.startswith("http"):
                                        try:
                                            sub = src.split('http')[1]
                                            sub = 'http%s'%sub
                                            try:
                                                sub = sub.split('&')[0]
                                            except:
                                                pass
                                        except:
                                            sub = 'false'
                                    else:                                                
                                        try:
                                            sub = src.split('http')[2]
                                            sub = 'http%s'%sub
                                            try:
                                                sub = sub.split('&')[0]
                                            except:
                                                pass
                                        except:
                                            sub = 'false'
                                else:
                                    sub = 'false'     
                                if 'http' in str(subtitle) and sub == 'false':
                                    try:
                                        sub = subtitle[0]
                                    except:
                                        sub = 'false'
                                if not src.startswith("http") and src !='false':
                                    if sub == 'false':
                                        sub_file = ''
                                    else:
                                        sub_file = sub
                                    link2 = 'http://suatela.com/playvideo/iframe.php?url=%s&legenda=%s'%(quote(src),quote(sub_file))
                                    ref = 'http://suatela.com/'
                                    data6 = navigator.open_url(link2,referer=ref)
                                    data6 = str(data6)
                                    source = re.compile('file: "(.*?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data6)
                                    if source:
                                        src = source[0]
                                    else:
                                        src = 'false'                                
                                if not src == 'false':
                                    #parsed_uri = urlparse(src)
                                    #point = parsed_uri.netloc
                                    #if point.count('.') > 1:
                                    #    try:
                                    #        server = point.split('.')[1]
                                    #    except:
                                    #            server = ''
                                    #else:
                                    #    try:
                                    #        server = point.split('.')[0]
                                    #    except:
                                    #        server = ''
                                    server = 'site 4'
                                    #servername = '| SUATELA | %s | %s'%(server.upper(), lg2)
                                    servername = '| SITE 4 | %s | %s'%(server.upper(), lg2)
                                    servers.append((servername,src,sub))
    elif search_id !='':
        url = '%s://%s/ajax/view.php?type=loading-post&id=%s'%(protocol,netloc,search_id)
        data2 = navigator.open_url(url,referer=referer)
        try:
            r = json.loads(data2)
        except:
            r = {}
        category = r.get('tipo')
        if category:
            url_list = ['%s://%s/ajax/view.php?type=loading-video&id=%s&category=%s&type_video=dublado', '%s://%s/ajax/view.php?type=loading-video&id=%s&category=%s&type_video=legendado']
            for url in url_list:
                lg = url.split('type_video=')[1]
                if lg == 'legendado':
                    lg2 = 'ORIGINAL'
                else:
                    lg2 = 'PORTUGUESE'
                url = url%(protocol,netloc,str(search_id),str(category))
                data3 = navigator.open_url(url,referer=referer)
                try:
                    r = json.loads(data3)
                except:
                    r = {}
                player = r.get('player')
                link = re.compile('date-url="(.*?)">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(player)
                if link:
                    try:
                        link = link[0]
                        data4 = navigator.open_url(link,referer=referer)
                    except:
                        data4 = ''
                    quality_1080p = re.compile("<input type='hidden' name='url_download_1080p' id='url_download_1080p' value='(.*?)'>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data4)
                    quality_720p = re.compile("<input type='hidden' name='url_download_720p' id='url_download_720p' value='(.*?)'>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data4)
                    quality_480p = re.compile("<input type='hidden' name='url_download_480p' id='url_download_480p' value='(.*?)'>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data4)
                    subtitle = re.compile("<input type='hidden' name='legenda_download' id='legenda_download' value='(.*?)'>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data4)
                    if 'http' in str(quality_1080p) or '/' in str(quality_1080p):
                        src = quality_1080p[0]
                    elif 'http' in str(quality_720p) or '/' in str(quality_720p):
                        src = quality_720p[0]
                    elif 'http' in str(quality_480p) or '/' in str(quality_480p):
                        src = quality_480p[0]
                    else:
                        src = 'false'                         
                    if '.srt' in src:
                        if not src.startswith("http"):
                            try:
                                sub = src.split('http')[1]
                                sub = 'http%s'%sub
                                try:
                                    sub = sub.split('&')[0]
                                except:
                                    pass
                            except:
                                sub = 'false'
                        else:                                                
                            try:
                                sub = src.split('http')[2]
                                sub = 'http%s'%sub
                                try:
                                    sub = sub.split('&')[0]
                                except:
                                    pass
                            except:
                                sub = 'false'
                    else:
                        sub = 'false'     
                    if 'http' in str(subtitle) and sub == 'false':
                        try:
                            sub = subtitle[0]
                        except:
                            sub = 'false'
                    if not src.startswith("http") and src !='false':
                        if sub == 'false':
                            sub_file = ''
                        else:
                            sub_file = sub
                        link2 = 'http://suatela.com/playvideo/iframe.php?url=%s&legenda=%s'%(quote(src),quote(sub_file))
                        ref = 'http://suatela.com/'
                        data6 = navigator.open_url(link2,referer=ref)
                        data6 = str(data6)
                        source = re.compile('file: "(.*?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data6)
                        if source:
                            src = source[0]
                        else:
                            src = 'false'                             
                    if not src == 'false':
                        #parsed_uri = urlparse(src)
                        #point = parsed_uri.netloc
                        #if point.count('.') > 1:
                        #    try:
                        #        server = point.split('.')[1]
                        #    except:
                        #        server = ''
                        #else:
                        #    try:
                        #        server = point.split('.')[0]
                        #    except:
                        #        server = ''
                        #try:
                        #    src = src.split('?')[0]
                        #except:
                        #    pass
                        #try:
                        #    src = src.split('#')[0]
                        #except:
                        #    pass
                        server = 'site 4'
                        #servername = '| SUATELA | %s | %s'%(server.upper(), lg2)
                        servername = '| SITE 4 | %s | %s'%(server.upper(), lg2)
                        servers.append((servername,src,sub))
    return servers    


def filmesmega(search,year):
    servers = []
    url = 'https://filmesmega.net/?s=%s'%quote(search).replace('%20', '+')
    referer = 'https://filmesmega.net/'
    data = navigator.open_url(url,referer=referer)
    title = re.compile('<div class="title">(.*?)</div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if title:
        items = re.compile('<a href="(.*?)" title.+?>(.*?)</a>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(str(title))
        if items:
            langs = []
            for url, name in items:
                if 'Dublado' in name:
                    name = name.split(' Dublado')[0]
                    lang = 'PORTUGUESE'
                elif ' Dual ' in name:
                    name = name.split(' Dual ')[0]
                    lang = 'DUAL'
                elif 'Legendado' in name:
                    name = name.split(' Legendado')[0]
                    lang = 'ORIGINAL'
                else:
                    lang = False
                if lang:
                    search = search.lower()
                    name = name.lower()
                    #try:
                    #    name = name.encode('latin-1').decode('utf-8')
                    #except:
                    #    pass
                    #name = name.encode('raw_unicode_escape').decode('utf-8')
                    name = fix_characters(name)
                    if search in name and len(search) == len(name):
                        langs.append((lang,url))
                        break
            if langs:
                for lang, url in langs:
                    data2 = navigator.open_url(url,referer=referer)
                    info = re.compile('<div class="info">(.*?)</div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data2)
                    if info:
                        search_year = re.compile('<i class="fa fa-calendar-o" aria-hidden="true"></i>.+?<span>(.*?)</span>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data2)
                        if search_year:
                            search_year = search_year[0]
                        else:
                            search_year = '0'
                    else:
                        search_year = '0'
                    if int(search_year) == int(year):                        
                        link_div = re.compile('<div id=.+?Link.+? Class=.+?Link.+?><a class.+?href="(.*?)" target="_blank">.+?</a></div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data2)
                        for link in link_div:
                            if 'pandafiles' in link or 'drive.google.com' in link:
                                parsed_uri = urlparse(link)
                                point = parsed_uri.netloc
                                if point.count('.') > 2:
                                    try:
                                        server = point.split('.')[2]
                                    except:
                                        server = ''                                    
                                elif point.count('.') > 1:
                                    try:
                                        server = point.split('.')[1]
                                    except:
                                        server = ''
                                else:
                                    try:
                                        server = point.split('.')[0]
                                    except:
                                        server = ''
                                sub = 'false'
                                servername = '| SITE 5 | %s | %s'%(server.upper(), lang)
                                servers.append((servername,link,sub))
    return servers

def netfilme(imdb):
    url = 'https://filmes.netfilme.com/embed/%s'%str(imdb)
    data = navigator.open_url(url,referer='https://meganews.tech/')
    servers = []
    iframe = re.findall("addiframe.+?'(.*?)'", data)
    if iframe:
        for server in iframe:
            if '/v/' in server:
                try:
                    id = server.split('/v/')[1]
                except:
                    id = False
                if id:
                    server = 'https://fembed.com/v/%s'%str(id)
            src = server
            try:
                sub = src.split('http')[2]
                sub = 'http%s'%sub
                try:
                    sub = sub.split('&')[0]
                except:
                    pass
                if not '.srt' in sub:
                    sub = 'false'                                            
            except:
                sub = 'false'                             
            parsed_uri = urlparse(src)
            servername = '| SITE 6 | %s'%(parsed_uri.netloc.split('.')[0].upper())
            servers.append((servername,src,sub))
    return servers

def animesonline_org(search,season,episode):
    from bs4 import BeautifulSoup
    url = 'https://animesonline.org/?s=%s'%quote(search).replace('%20', '+')
    url_parsed = urlparse(url)
    protocol = url_parsed.scheme
    netloc = url_parsed.netloc
    referer = 'https://animesonline.org/'
    data = navigator.open_url(url,referer=referer)
    main = re.compile(r'<div class="title">.+?<a href="(.*?)">(.*?)</a></div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    servers = []
    if main:
        langs = []
        for link, name in main:
            name = name.replace("&#8217;", "'")
            if 'Dublado' in name:
                try:
                    name = name.split(' Dublado')[0]
                except:
                    pass
                try:
                    name = name.split(' - Dublado')[0]
                except:
                    pass
                try:
                    name = name.split('- Dublado')[0]
                except:
                    pass                    
                lang = 'PORTUGUESE'
            else:
                lang = 'ORIGINAL'
            name_search = name.lower()
            name_search = name_search.strip()
            search = search.lower()
            search = search.strip()
            if search in name_search and len(search) == len(name_search):
                langs.append((lang,link))
        if langs:
            for lang, link in langs:
                data2 = navigator.open_url(link,referer=referer)
                soup = BeautifulSoup(data2, "html.parser")
                seasons = soup.find(id="seasons")
                episodes_by_season = seasons.find_all("ul", class_="episodios temp"+str(season))                
                episodes = re.compile(r'<div class="numerando">(.*?) - (.*?)</div><div class="episodiotitle"><a href="(.*?)">.+?</a>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(str(episodes_by_season))
                for season_, episode_, url in episodes:
                    if int(season_) == int(season) and int(episode_) == int(episode):
                        data3 = navigator.open_url(url,referer=referer)
                        iframe = re.compile(r"<iframe class.+?src='(.*?)'.+?></iframe>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data3)
                        if iframe:
                            iframe = iframe[0]
                        else:
                            iframe = False
                        if iframe:
                            data4 = navigator.open_url(iframe,referer=referer)
                            src = re.compile(r'{"file":"(.*?)","type":"hls","label":"(.*?)"}', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data4)
                            if not src:
                                src = re.compile(r'{ file: "(.*?)", label: "(.*?)" ,type: "video/mp4" }', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data4)
                            if not src:
                                src = re.compile(r'{"file":"(.*?)","type":"video/mp4","label":"(.*?)"}', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data4)
                            if src:
                                src_final = ''
                                for url, tp in src:
                                    if '1080' in tp:
                                        src_final += url
                                        break
                                    elif '720' in tp:
                                        src_final += url
                                        break
                                    elif '480' in tp:
                                        src_final += url
                                        break
                                    elif '360' in tp:
                                        src_final += url
                                        break
                                if src_final !='':                                
                                    parsed_uri = urlparse(src_final)
                                    point = parsed_uri.netloc
                                    if point.count('.') > 2:
                                        try:
                                            server = point.split('.')[2]
                                        except:
                                            server = ''                                    
                                    elif point.count('.') > 1:
                                        try:
                                            server = point.split('.')[1]
                                        except:
                                            server = ''
                                    else:
                                        try:
                                            server = point.split('.')[0]
                                        except:
                                            server = ''
                                    sub = 'false'
                                    #servername = '| ANIMESONLINE | %s | %s'%(server.upper(), lang)
                                    servername = '| ANIMES 1 | %s | %s'%(server.upper(), lang)
                                    servers.append((servername,src_final,sub))
    return servers
    
def blogger_resolve(url):
    data = navigator.open_url(url)
    links = re.compile('{"play_url":"(.*?)","format_id":(.*?)}', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    resolved = ''
    for link, quality in links:
        link = link.encode('utf-8').decode('unicode_escape')
        if int(quality) == 22:
            resolved += link
            break
        elif int(quality) == 18:
            resolved += link
            break
    return resolved

def animesonline_cc(search,season,episode):
    url = 'https://animesonline.cc/?s=%s'%quote(search).replace('%20', '+')
    url_parsed = urlparse(url)
    protocol = url_parsed.scheme
    netloc = url_parsed.netloc
    referer = 'https://animesonline.cc/'
    data = navigator.open_url(url,referer=referer)
    servers = []
    main = re.compile(r'<div class="data"><h3> <a href="(.*?)">(.*?)</a></h3></div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if main:
        langs = []
        for link, name in main:
            name = name.replace("&#8217;", "'")
            if 'Dublado' in name:
                try:
                    name = name.split(' Dublado')[0]
                except:
                    pass
                try:
                    name = name.split(' - Dublado')[0]
                except:
                    pass
                try:
                    name = name.split('- Dublado')[0]
                except:
                    pass                    
                lang = 'PORTUGUESE'
            else:
                lang = 'ORIGINAL'
            name_search = name.lower()
            name_search = name_search.strip()
            search = search.lower()
            search = search.strip()
            if search in name_search and len(search) == len(name_search):
                langs.append((lang,link))
        if langs:
            for lang, link in langs:
                data2 = navigator.open_url(link,referer=referer)               
                season_re = re.compile('<div class="se-c"><div class="se-q">.+?<span class="title">Temporada  '+str(season)+' </span>(.+?)</div></div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data2)
                episodes_re = re.compile('<img src.+?>.+?<a href="(.+?)">(.+?)</a>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(str(season_re))
                pages = []
                for url, episode_ in episodes_re:
                    episode_ = episode_.replace('Episodio ', '').replace('Episódio ', '')                    
                    if int(episode_) == int(episode):
                        pages.append(url)
                        break
                if pages:
                    for page in pages:
                        data3 = navigator.open_url(page,referer=referer) 
                        option_1_re = re.compile('<div id="option-1".+?iframe.+?src="(.+?)".+?</div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data3)
                        option_2_re = re.compile('<div id="option-2".+?iframe.+?src="(.+?)".+?</div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data3)     
                        option_1_2_re = re.compile('<div id="option-1".+?source.+?src="(.+?)".+?</div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data3)
                        option_2_2_re = re.compile('<div id="option-2".+?source.+?src="(.+?)".+?</div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data3)
                        if option_1_re !=[]:
                            src_final = option_1_re[0]
                            if 'blogger' in src_final:
                                src_final = blogger_resolve(src_final)                                
                            if src_final !='':                                
                                parsed_uri = urlparse(src_final)
                                point = parsed_uri.netloc
                                if point.count('.') > 2:
                                    try:
                                        server = point.split('.')[2]
                                    except:
                                        server = ''                                    
                                elif point.count('.') > 1:
                                    try:
                                        server = point.split('.')[1]
                                    except:
                                        server = ''
                                else:
                                    try:
                                        server = point.split('.')[0]
                                    except:
                                        server = ''
                                lang = 'ORIGINAL'
                                sub = 'false'
                                servername = '| ANIMES 2 | %s | %s'%(server.upper(), lang)
                                servers.append((servername,src_final,sub))
                        elif option_1_2_re !=[]:
                            src_final = option_1_2_re[0]
                            if 'blogger' in src_final:
                                src_final = blogger_resolve(src_final)                            
                            if src_final !='':                                
                                parsed_uri = urlparse(src_final)
                                point = parsed_uri.netloc
                                if point.count('.') > 2:
                                    try:
                                        server = point.split('.')[2]
                                    except:
                                        server = ''                                    
                                elif point.count('.') > 1:
                                    try:
                                        server = point.split('.')[1]
                                    except:
                                        server = ''
                                else:
                                    try:
                                        server = point.split('.')[0]
                                    except:
                                        server = ''
                                lang = 'ORIGINAL'
                                sub = 'false'
                                servername = '| ANIMES 2 | %s | %s'%(server.upper(), lang)
                                servers.append((servername,src_final,sub))
                        if option_2_re !=[]:
                            src_final = option_2_re[0]
                            if 'blogger' in src_final:
                                src_final = blogger_resolve(src_final)                            
                            if src_final !='':                                
                                parsed_uri = urlparse(src_final)
                                point = parsed_uri.netloc
                                if point.count('.') > 2:
                                    try:
                                        server = point.split('.')[2]
                                    except:
                                        server = ''                                    
                                elif point.count('.') > 1:
                                    try:
                                        server = point.split('.')[1]
                                    except:
                                        server = ''
                                else:
                                    try:
                                        server = point.split('.')[0]
                                    except:
                                        server = ''
                                lang = 'PORTUGUESE'
                                sub = 'false'
                                servername = '| ANIMES 2 | %s | %s'%(server.upper(), lang)
                                servers.append((servername,src_final,sub))
                        elif option_2_2_re !=[]:
                            src_final = option_2_2_re[0]
                            if 'blogger' in src_final:
                                src_final = blogger_resolve(src_final)                            
                            if src_final !='':                                
                                parsed_uri = urlparse(src_final)
                                point = parsed_uri.netloc
                                if point.count('.') > 2:
                                    try:
                                        server = point.split('.')[2]
                                    except:
                                        server = ''                                    
                                elif point.count('.') > 1:
                                    try:
                                        server = point.split('.')[1]
                                    except:
                                        server = ''
                                else:
                                    try:
                                        server = point.split('.')[0]
                                    except:
                                        server = ''
                                lang = 'PORTUGUESE'
                                sub = 'false'
                                servername = '| ANIMES 2 | %s | %s'%(server.upper(), lang)
                                servers.append((servername,src_final,sub))
    return servers    

def resolver_stream(imdb,search1,search2,year,season=False,episode=False):
    dp = xbmcgui.DialogProgress()
    if season == 'false':
        season = False
    if episode == 'false':
        episode = False
    resolved = []
    if six.PY3:
        dp.create(lang.id('please_wait'),lang.id('looking_for_links'))
    else:
        dp.create(lang.id('please_wait'),lang.id('looking_for_links'), '','')
    if season and episode:
        if six.PY3:
            #dp.update(0, 'WAREZCDN')
            dp.update(0, 'SITE 1')
        else:
            #dp.update(0, 'WAREZCDN','', '')
            dp.update(0, 'SITE 1','', '')
        if dp.iscanceled():
            raise Error
        try:
            sv = warezcdn(imdb,season,episode)
        except:
            sv = []
        if dp.iscanceled():
            raise Error        
        for name,server,subtitle in sv:
            if not server in str(resolved):
                resolved.append((name,server,subtitle))
        if six.PY3:
            #dp.update(25, 'VIZERTV')
            dp.update(25, 'SITE 2')
        else:
            #dp.update(25, 'VIZERTV','', '')
            dp.update(25, 'SITE 2','', '')
        if dp.iscanceled():
            raise Error
        try:
            sv2 = vizertv(search1, year, season, episode)
        except:
            sv2 = []
        if dp.iscanceled():
            raise Error          
        if sv2 !=[]:
            for name,server,subtitle in sv2:
                if not server in str(resolved):
                    resolved.append((name,server,subtitle))
        else:
            try:
                sv2 = vizertv(search2, year, season, episode)
            except:
                sv2 = []
            if dp.iscanceled():
                raise Error             
            if sv2 !=[]:
                for name,server,subtitle in sv2:
                    if not server in str(resolved):
                        resolved.append((name,server,subtitle))
            else:
                if dp.iscanceled():
                    raise Error 
                if ':' in search1:
                    search = search1.split(':')
                    if search !=[]:
                        search = search[0]
                        try:
                            sv2 = vizertv(search, year, season, episode)
                        except:
                            sv2 = []
                        for name,server,subtitle in sv2:
                            if not server in str(resolved):
                                resolved.append((name,server,subtitle))
        if six.PY3:
            #dp.update(50, 'NOVOVIZER')
            dp.update(50, 'SITE 3')
        else:
            #dp.update(50, 'NOVOVIZER','', '')
            dp.update(50, 'SITE 3','', '')
        if dp.iscanceled():
            raise Error
        try:
            sv3 = novovizer(search1, year, season, episode)
        except:
            sv3 = []
        if dp.iscanceled():
            raise Error         
        if sv3 !=[]:
            for name,server,subtitle in sv3:
                if not server in str(resolved):
                    resolved.append((name,server,subtitle))
        else:
            try:
                sv3 = novovizer(search2, year, season, episode)
            except:
                sv3 = []
            if dp.iscanceled():
                raise Error             
            if sv3 !=[]:
                for name,server,subtitle in sv3:
                    if not server in str(resolved):
                        resolved.append((name,server,subtitle))
            else:
                if dp.iscanceled():
                    raise Error             
                if ':' in search1:
                    search = search1.split(':')
                    if search !=[]:
                        search = search[0]
                        try:
                            sv3 = novovizer(search, year, season, episode)
                        except:
                            sv3 = []
                        for name,server,subtitle in sv2:
                            if not server in str(resolved):
                                resolved.append((name,server,subtitle))                                
                if '&' and ':' in search1:
                    search = search1.split(':')
                    if search !=[]:
                        search = search[0]
                    search = search.replace('&', 'e')
                    try:
                        sv3 = novovizer(search, year, season, episode)
                    except:
                        sv3 = []
                    for name,server,subtitle in sv3:
                        if not server in str(resolved):
                            resolved.append((name,server,subtitle))
                if '&' in search1:
                    search = search1.replace('&', 'e')
                    try:
                        sv3 = novovizer(search, year, season, episode)
                    except:
                        sv3 = []
                    for name,server,subtitle in sv3:
                        if not server in str(resolved):
                            resolved.append((name,server,subtitle))
                if ' e ' in search1:
                    search = search1.replace(' e ', ' & ')
                    try:
                        sv3 = novovizer(search, year, season, episode)
                    except:
                        sv3 = []
                    for name,server,subtitle in sv3:
                        if not server in str(resolved):
                            resolved.append((name,server,subtitle))
        if six.PY3:
            #dp.update(75, 'SUATELA')
            dp.update(75, 'SITE 4')
        else:
            #dp.update(75, 'SUATELA','', '')
            dp.update(75, 'SITE 4','', '')
        try:
            sv4 = suatela(search1,year,season,episode)
        except:
            sv4 = []
        if sv4 !=[]:
            for name,server,subtitle in sv4:
                if not server in str(resolved):
                    resolved.append((name,server,subtitle))
        else:
            try:
                sv4 = suatela(search2,year,season,episode)
            except:
                sv4 = []
            if sv4 !=[]:
                for name,server,subtitle in sv4:
                    if not server in str(resolved):
                        resolved.append((name,server,subtitle))
            else:
                if ':' in search1:
                    search = search1.replace(': ', ' - ')
                    try:
                        sv4 = suatela(search,year,season,episode)
                    except:
                        sv4 = []
                    for name,server,subtitle in sv4:
                        if not server in str(resolved):
                            resolved.append((name,server,subtitle))            
                if ':' in search1:
                    search = search1.split(':')
                    if search !=[]:
                        search = search[0]
                        try:
                            sv4 = suatela(search,year,season,episode)
                        except:
                            sv4 = []
                        for name,server,subtitle in sv4:
                            if not server in str(resolved):
                                resolved.append((name,server,subtitle))
                if '&' and ':' in search1:
                    search = search1.split(':')
                    if search !=[]:
                        search = search[0]
                        search = search.replace('&', 'e')
                        try:
                            sv4 = suatela(search,year,season,episode)
                        except:
                            sv4 = []
                        for name,server,subtitle in sv4:
                            if not server in str(resolved):
                                resolved.append((name,server,subtitle))
                if '&' in search1:
                    search = search1.replace('&', 'e')
                    try:
                        sv3 = suatela(search, year, season, episode)
                    except:
                        sv3 = []
                    for name,server,subtitle in sv3:
                        if not server in str(resolved):
                            resolved.append((name,server,subtitle))
                if ' e ' in search1:
                    search = search1.replace(' e ', ' & ')
                    sv3 = suatela(search, year, season, episode)
                    for name,server,subtitle in sv3:
                        if not server in str(resolved):
                            resolved.append((name,server,subtitle))
        if six.PY3:
            dp.update(100, '')
        else:
            dp.update(100, '','', '') 
    else:
        if six.PY3:
            #dp.update(0, 'WAREZCDN')
            dp.update(0, 'SITE 1')
        else:
            #dp.update(0, 'WAREZCDN','', '')
            dp.update(0, 'SITE 1','', '')
        if dp.iscanceled():
            raise Error
        try:
            sv = warezcdn(imdb,season=False,episode=False)
        except:
            sv = []
        for name,server,subtitle in sv:
            if not server in str(resolved):
                resolved.append((name,server,subtitle))
        if six.PY3:
            #dp.update(25, 'VIZERTV')
            dp.update(16, 'SITE 2')
        else:
            #dp.update(25, 'VIZERTV','', '')
            dp.update(16, 'SITE 2','', '')
        if dp.iscanceled():
            raise Error
        try:
            sv2 = vizertv(search1, year, season=False, episode=False)
        except:
            sv2 = []
        if dp.iscanceled():
            raise Error         
        if sv2 !=[]:
            for name,server,subtitle in sv2:
                if not server in str(resolved):
                    resolved.append((name,server,subtitle))
        else:
            try:
                sv2 = vizertv(search2, year, season=False, episode=False)
            except:
                sv2 = []
            if dp.iscanceled():
                raise Error             
            if sv2 !=[]:
                for name,server,subtitle in sv2:
                    if not server in str(resolved):
                        resolved.append((name,server,subtitle))                        
            else:
                if dp.iscanceled():
                    raise Error             
                if ':' in search1:
                    search = search1.split(':')
                    if search !=[]:
                        search = search[0]
                        try:
                            sv2 = vizertv(search, year, season=False, episode=False)
                        except:
                            sv2 = []
                        for name,server,subtitle in sv2:
                            if not server in str(resolved):
                                resolved.append((name,server,subtitle))
        if six.PY3:
            #dp.update(50, 'NOVOVIZER')
            dp.update(32, 'SITE 3')
        else:
            #dp.update(50, 'NOVOVIZER','', '')
            dp.update(32, 'SITE 3','', '')
        if dp.iscanceled():
            raise Error
        try:
            sv3 = novovizer(search1, year, season=False, episode=False)
        except:
            sv3 = []
        if dp.iscanceled():
            raise Error         
        if sv3 !=[]:
            for name,server,subtitle in sv3:
                if not server in str(resolved):
                    resolved.append((name,server,subtitle))
        else:
            try:
                sv3 = novovizer(search2, year, season=False, episode=False)
            except:
                sv3 = []
            if dp.iscanceled():
                raise Error            
            if sv3 !=[]:
                for name,server,subtitle in sv3:
                    if not server in str(resolved):
                        resolved.append((name,server,subtitle))
            else:
                if dp.iscanceled():
                    raise Error             
                if ':' in search1:
                    search = search1.split(':')
                    if search !=[]:
                        search = search[0]
                        try:
                            sv3 = novovizer(search, year, season=False, episode=False)
                        except:
                            sv3 = []
                        for name,server,subtitle in sv3:
                            if not server in str(resolved):
                                resolved.append((name,server,subtitle))
                if '&' and ':' in search1:
                    search = search1.split(':')
                    if search !=[]:
                        search = search[0]
                    search = search.replace('&', 'e')
                    try:
                        sv3 = novovizer(search, year, season=False, episode=False)
                    except:
                        sv3 = []
                    for name,server,subtitle in sv3:
                        if not server in str(resolved):
                            resolved.append((name,server,subtitle))
                if '&' in search1:
                    search = search1.replace('&', 'e')
                    try:
                        sv3 = novovizer(search, year, season=False, episode=False)
                    except:
                        sv3 = []
                    for name,server,subtitle in sv3:
                        if not server in str(resolved):
                            resolved.append((name,server,subtitle))
                if ' e ' in search1:
                    search = search1.replace(' e ', ' & ')
                    try:
                        sv3 = novovizer(search, year, season=False, episode=False)
                    except:
                        sv3 = []
                    for name,server,subtitle in sv3:
                        if not server in str(resolved):
                            resolved.append((name,server,subtitle))
        if dp.iscanceled():
            raise Error        
        #suatela season e episode
        if six.PY3:
            #dp.update(75, 'SUATELA')
            dp.update(48, 'SITE 4')
        else:
            #dp.update(75, 'SUATELA','', '')
            dp.update(48, 'SITE 4','', '')            
        try:
            sv4 = suatela(search1,year,season=False,episode=False)
        except:
            sv4 = []
        if sv4 !=[]:
            for name,server,subtitle in sv4:
                if not server in str(resolved):
                    resolved.append((name,server,subtitle))
        else:
            try:
                sv4 = suatela(search2,year,season=False,episode=False)
            except:
                sv4 = []
            if sv4 !=[]:
                for name,server,subtitle in sv4:
                    if not server in str(resolved):
                        resolved.append((name,server,subtitle))
            else:
                if ':' in search1:
                    search = search1.replace(': ', ' - ')
                    try:
                        sv4 = suatela(search,year,season=False,episode=False)
                    except:
                        sv4 = []
                    for name,server,subtitle in sv4:
                        if not server in str(resolved):
                            resolved.append((name,server,subtitle))                 
                if ':' in search1:
                    search = search1.split(':')
                    if search !=[]:
                        search = search[0]
                        try:
                            sv4 = suatela(search,year,season=False,episode=False)
                        except:
                            sv4 = []
                        for name,server,subtitle in sv4:
                            if not server in str(resolved):
                                resolved.append((name,server,subtitle))
                if '&' and ':' in search1:
                    search = search1.split(':')
                    if search !=[]:
                        search = search[0]
                        search = search.replace('&', 'e')
                        try:
                            sv4 = suatela(search,year,season=False,episode=False)
                        except:
                            sv4 = []
                        for name,server,subtitle in sv4:
                            if not server in str(resolved):
                                resolved.append((name,server,subtitle))
                if '&' in search1:
                    search = search1.replace('&', 'e')
                    try:
                        sv4 = suatela(search, year, season=False, episode=False)
                    except:
                        sv4 = []
                    for name,server,subtitle in sv4:
                        if not server in str(resolved):
                            resolved.append((name,server,subtitle))
                if ' e ' in search1:
                    search = search1.replace(' e ', ' & ')
                    try:
                        sv4 = suatela(search, year, season=False, episode=False)
                    except:
                        sv4 = []
                    for name,server,subtitle in sv4:
                        if not server in str(resolved):
                            resolved.append((name,server,subtitle))       
        if dp.iscanceled():
            raise Error        
        if six.PY3:
            dp.update(64, 'SITE 5')
        else:
            dp.update(64, 'SITE 5','', '')                     
        try:
            sv5 = filmesmega(search1,year)
        except:
            sv5 = []
        if sv5 !=[]:
            for name,server,subtitle in sv5:
                if not server in str(resolved):
                    resolved.append((name,server,subtitle))
        else:
            try:
                sv5 = filmesmega(search2,year)
            except:
                sv5 = []
            if sv5 !=[]:
                for name,server,subtitle in sv5:
                    if not server in str(resolved):
                        resolved.append((name,server,subtitle))
            else:
                if ':' in search1:
                    search = search1.replace(':', '')
                    try:
                        sv5 = filmesmega(search,year)
                    except:
                        sv5 = []
                    if sv5 !=[]:
                        for name,server,subtitle in sv5:
                            if not server in str(resolved):
                                resolved.append((name,server,subtitle))              
                if '&' and ':' in search1:
                    part = search1.split(':')
                    if part:
                        part = part[0]
                        part_replace = part.replace('&', 'e')
                        search = search1.replace(part,part_replace)
                        try:
                            sv5 = filmesmega(search,year)
                        except:
                            sv5 = []
                        if sv5 !=[]:
                            for name,server,subtitle in sv5:
                                if not server in str(resolved):
                                    resolved.append((name,server,subtitle))
                elif '&' in search1:
                    search = search1.replace('&', 'e')
                    try:
                        sv5 = filmesmega(search,year)
                    except:
                        sv5 = []
                    if sv5 !=[]:
                        for name,server,subtitle in sv5:
                            if not server in str(resolved):
                                resolved.append((name,server,subtitle))
                elif ' e ' in search1:
                    search = search1.replace('e', '&')
                    try:
                        sv5 = filmesmega(search,year)
                    except:
                        sv5 = []
                    if sv5 !=[]:
                        for name,server,subtitle in sv5:
                            if not server in str(resolved):
                                resolved.append((name,server,subtitle))                             
        if dp.iscanceled():
            raise Error
        if six.PY3:
            dp.update(80, 'SITE 6')
        else:
            dp.update(80, 'SITE 6','', '')            
        try:
            sv6 = netfilme(imdb)
        except:
            sv6 = []
        if sv6 !=[]:
            for name,server,subtitle in sv6:
                if not server in str(resolved):
                    resolved.append((name,server,subtitle))
        if six.PY3:
            dp.update(100, '')
        else:
            dp.update(100, '','', '')
        if dp.iscanceled():
            raise Error            
    num_items = []
    if resolved !=[]:
        count = 0
        for name, server, subtitle in resolved:
            count += 1
            name = '%s %s'%(str(count), name)
            num_items.append((name,server,subtitle))
    return num_items

def servers_list(name,iconimage,fanart,description,genre,imdb,search1,search2,originaltitle,video_title,year,season,episode):
    try:
        servers = resolver_stream(imdb,search1,search2,year,season,episode)
        stream = True
    except:        
        servers = []
        stream = False 
    if len(servers) > 0:
        xbmcplugin.setContent(handle, 'videos')
        for name, server, subtitle in servers:
            if season and episode:
                control.item({'name':name.encode('utf-8', 'ignore'),'action': 'play', 'url': server, 'iconimage': iconimage, 'fanart': fanart, 'description': description, 'genre': genre, 'video_title': video_title, 'season': season, 'episode': episode, 'imdbnumber': imdb, 'originaltitle': originaltitle, 'playable': 'false', 'subtitle': subtitle, 'year': year},folder=False)
            else:
                control.item({'name':name.encode('utf-8', 'ignore'),'action': 'play', 'url': server, 'iconimage': iconimage, 'fanart': fanart, 'description': description, 'genre': genre, 'video_title': video_title, 'imdbnumber': imdb, 'originaltitle': originaltitle, 'playable': 'false', 'subtitle': subtitle, 'year': year},folder=False)
        xbmcplugin.endOfDirectory(handle)
    elif stream == False:
        pass
    else:
        control.infoDialog(lang.id('no_stream_available'), iconimage='INFO')
    

def resolver_stream2(search,season,episode):
    dp = xbmcgui.DialogProgress()
    if season == 'false':
        season = False
    if episode == 'false':
        episode = False
    resolved = []
    if six.PY3:
        dp.create(lang.id('please_wait'),lang.id('looking_for_links'))
    else:
        dp.create(lang.id('please_wait'),lang.id('looking_for_links'), '','')
    if season and episode:
        if six.PY3:
            dp.update(0, 'ANIMES 1')
        else:
            dp.update(0, 'ANIMES 1','', '')
        try:
            sv = animesonline_org(search,season,episode)
        except:
            sv = []
        if sv:
            for name, server, subtitle in sv:
                if not server in resolved:
                    resolved.append((name, server, subtitle))
        if not sv:
            search2 = search.replace(':', '').replace('Shippuuden', 'Shippuden')
            try:
                sv = animesonline_org(search2,season,episode)
            except:
                sv = []
            if sv:
                for name, server, subtitle in sv:
                    if not server in resolved:
                        resolved.append((name, server, subtitle))
        if dp.iscanceled():
            raise Error                        
        if six.PY3:
            dp.update(0, 'ANIMES 2')
        else:
            dp.update(0, 'ANIMES 2','', '')
        try:
            sv2 = animesonline_cc(search,season,episode)
        except:
            sv2 = []
        if sv2: 
            for name, server, subtitle in sv2:
                if not server in resolved:
                    resolved.append((name, server, subtitle))                    
        if not sv2:
            search3 = search.replace(':', '').replace('Shippuuden', 'Shippuden')
            try:
                sv2 = animesonline_org(search3,season,episode)
            except:
                sv2 = []
            if sv2:
                for name, server, subtitle in sv2:
                    if not server in resolved:
                        resolved.append((name, server, subtitle))
        if dp.iscanceled():
            raise Error
        if six.PY3:
            dp.update(100, '')
        else:
            dp.update(100, '','', '')             
    num_items = []
    if resolved !=[]:
        count = 0
        for name, server, subtitle in resolved:
            count += 1
            name = '%s %s'%(str(count), name)
            num_items.append((name,server,subtitle))
    return num_items
    
def servers_list2(originalname,iconimage,fanart,description,search,season,episode):
    try:
        servers = resolver_stream2(search,season,episode)
        stream = True
    except:        
        servers = []
        stream = False 
    if len(servers) > 0:
        xbmcplugin.setContent(handle, 'videos')
        for name, server, subtitle in servers:
            if season and episode:
                control.item({'name':name.encode('utf-8', 'ignore'),'action': 'play3', 'url': server, 'iconimage': iconimage, 'fanart': fanart, 'description': description, 'video_title': originalname, 'season': season, 'episode': episode, 'playable': 'false', 'subtitle': subtitle},folder=False)
        xbmcplugin.endOfDirectory(handle)
    elif stream == False:
        pass
    else:
        control.infoDialog(lang.id('no_stream_available'), iconimage='INFO')    


def megafilmeshds(url):
    data = navigator.open_url(url,referer='https://megafilmeshds.com/')
    iframe = re.compile('<IFRAME.+?SRC="(.*?)".+?></IFRAME>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if iframe !=[]:
        data2 = navigator.open_url(iframe[0],referer=url)
        source = re.compile('source.+?src="(.*?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data2)
        if source !=[]:
            url = source[0]
        else:
            url = False
    else:
        url = False
    return url

def wolfstream_tv(url):
    import random
    data = navigator.open_url(url,referer=url)
    sources = re.compile('file:"(.*?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if sources !=[]:
        url = random.choice(sources)
    else:
        url = False
    return url

def streamtape(url):
    correct_url = url.replace('/v/', '/e/')
    parsed_uri = urlparse(url)
    protocol = parsed_uri.scheme
    host = parsed_uri.netloc
    referer = '%s://%s'%(protocol,host)
    data = navigator.open_url(correct_url,referer=referer)
    link_part1_re = re.compile('<div.+?style="display:none;">(.*?)&token=.+?</div>').findall(data)
    link_part2_re = re.compile("&token=(.*?)'").findall(data)
    if link_part1_re and link_part2_re:
        part1 = link_part1_re[0]
        part2 = link_part2_re[-1]
        part1 = part1.replace(' ', '')
        if 'streamtape' in part1:
            try:
                part1 = part1.split('streamtape')[1]
                final = 'streamtape' + part1 + '&token=' + part2
                stream = 'https://' + final + '&stream=1'
                link = navigator.last_url(stream,referer=referer)                
                link = link + navigator.headers(referer=stream)
            except:
                link = False
        elif 'get_video' in part1:
            try:
                part1_1 = part1.split('get_video')[0]
                part1_2 = part1.split('get_video')[1]
                part1_1 = part1_1.replace('/', '')
                part1 = part1_1 + '/get_video' + part1_2
                final = part1 + '&token=' + part2
                stream = 'https://' + final + '&stream=1'
                link = navigator.last_url(stream,referer=referer)
                link = link + navigator.headers(referer=stream)
            except:
                link = False
        else:
            link = False
    else:
        link = False
    return link
    
def pandafiles(url):
    agent = navigator.UA
    url_parsed = urlparse(url)
    hostname = '%s://%s'%(url_parsed.scheme,url_parsed.netloc)
    origin = hostname
    referer = url
    try:
        id = url.split(url_parsed.netloc + '/')[1]
    except:
        pass
    try:
        id = id.split('/')[0]
    except:
        pass
    post = {'op': 'download2', 'usr_login': '', 'id': id, 'referer': quote(url), 'method_free': 'Free Download'}
    data = navigator.open_url(url,post=post)
    a = re.compile('<div id="direct_link">.+?<a href="(.*?)"><i class="fa fa-cloud-download">', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if a:
        stream = a[0] + '|User-Agent=' + quote_plus(agent) + '&Origin=' + quote_plus(origin) + '&Referer=' + quote_plus(referer) + '&verifypeer=false'
    else:
        stream = False
    return stream

def playseries_megaseries_net(url):
    data = navigator.open_url(url,referer='https://novovizer.com/')
    source = re.compile("{.+?src:.+?'(.*?)'.+?size:(.*?)}", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    part2 = ''
    if source:
        for link, quality in source:
            quality = quality.replace(' ', '')
            if quality == '1080':
                part2 += link
                break
            elif quality == '720':
                part2 += link
                break
            elif quality == '480':
                part2 += link
                break
            elif quality == '360':
                part2 += link
                break
    if part2 !='':
        if 'https' in url:
            protocol = 'https'
        else:
            protocol = 'http'
        redirect = protocol+'://playseries.megaseries.net'+part2
        try:
            link = navigator.last_url(redirect,referer=url)
        except:
            link = False
    else:
        link = False
    return link
        
def resolve_url(url):
    dp = xbmcgui.DialogProgress()
    if six.PY3:
        dp.create(lang.id('please_wait'),lang.id('resolving_link'))
    else:
        dp.create(lang.id('please_wait'),lang.id('resolving_link'), '','')    
    if 'megafilmeshds.com' in url:
        url = megafilmeshds(url)
    elif 'novovizer.online' in url:
        newurl = url.replace('novovizer.online', 'fembed.com')
        url = resolve_url(newurl)
    elif 'filmesmp4' in url and '/stream/' in url:
        url = url
    elif 'playseries.megaseries.net' in url:
        url = playseries_megaseries_net(url)
    elif 'wixstatic' in url:
        url = url
    elif '.m3u8' in url:
        url = url
    elif 'pandafiles' in url:
        link = pandafiles(url)
        if link == False:
            try:
                import resolveurl as urlresolver
                link = urlresolver.resolve(url)
            except:
                link = False
        url = link            
    elif 'streamtape' in url:
        link = streamtape(url)
        if link == False:
            try:
                import resolveurl as urlresolver
                link = urlresolver.resolve(url)
            except:
                link = False
        url = link        
    else:
        try:
            import resolveurl as urlresolver
            url = urlresolver.resolve(url)
        except:
            url = False
    if six.PY3:
        dp.update(100, '')
    else:
        dp.update(100, '','', '')            
    return url

def resolve_url2(url):
    if 'blogger' in url:
        try:
            import resolveurl as urlresolver
            url = urlresolver.resolve(url)
        except:
            url = False
    return url
        
        

def play(name,url,iconimage,fanart,description,genre,imdbnumber,originaltitle,year,season,episode,playable,subtitle):
    url = resolve_url(url)
    if not season == 'false' and not episode == 'false':
        if int(season) < 10:
            sdesc = '0%s'%str(season)
        else:
            sdesc = str(season)
        if int(episode) < 10:
            edesc = '0%s'%str(episode)
        else:
            edesc = str(episode)
        name = '%s - S%sE%s'%(name,sdesc,edesc)
    if url:    
        if six.PY3:
            li=xbmcgui.ListItem(name, path=url)
            if iconimage:
                #li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
                li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
        else:
            li = xbmcgui.ListItem(name, path=url, iconImage=iconimage, thumbnailImage=iconimage)
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        if not genre == 'false':
            try:
                li.setInfo('video', { 'genre': str(genre) })
            except:
                pass 
        if not imdbnumber == 'false':
            try:
                li.setInfo('video', { 'imdbnumber': str(imdbnumber) })
            except:
                pass
        if not originaltitle == 'false':
            try:
                li.setInfo('video', { 'originaltitle': str(originaltitle) })
            except:
                pass
        if not year == '0' and not year == 0:
            try:
                li.setInfo('video', { 'year': int(year) })
            except:
                pass                
        if not season == 'false':
            try:
                li.setInfo('video', { 'season': int(season) })
            except:
                pass
        if not episode == 'false':
            try:
                li.setInfo('video', { 'episode': int(episode) })
            except:
                pass               
        if not subtitle == 'false':
            li.setSubtitles([subtitle])
        if not playable == 'false':
            xbmcplugin.setResolvedUrl(handle, True, li)
        else:
            xbmc.Player().play(item=url, listitem=li)
    else:
        control.infoDialog(lang.id('no_stream_available'), iconimage='INFO')
        
def play3(name,url,iconimage,fanart,description,genre,imdbnumber,originaltitle,year,season,episode,playable,subtitle):
    if not season == 'false' and not episode == 'false':
        if int(season) < 10:
            sdesc = '0%s'%str(season)
        else:
            sdesc = str(season)
        if int(episode) < 10:
            edesc = '0%s'%str(episode)
        else:
            edesc = str(episode)
        name = '%s - S%sE%s'%(name,sdesc,edesc)
    if url:    
        if six.PY3:
            li=xbmcgui.ListItem(name, path=url)
            if iconimage:
                #li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
                li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
        else:
            li = xbmcgui.ListItem(name, path=url, iconImage=iconimage, thumbnailImage=iconimage)
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        if not genre == 'false':
            try:
                li.setInfo('video', { 'genre': str(genre) })
            except:
                pass 
        if not imdbnumber == 'false':
            try:
                li.setInfo('video', { 'imdbnumber': str(imdbnumber) })
            except:
                pass
        if not originaltitle == 'false':
            try:
                li.setInfo('video', { 'originaltitle': str(originaltitle) })
            except:
                pass
        if not year == '0' and not year == 0:
            try:
                li.setInfo('video', { 'year': int(year) })
            except:
                pass                
        if not season == 'false':
            try:
                li.setInfo('video', { 'season': int(season) })
            except:
                pass
        if not episode == 'false':
            try:
                li.setInfo('video', { 'episode': int(episode) })
            except:
                pass               
        if not subtitle == 'false':
            li.setSubtitles([subtitle])
        if not playable == 'false':
            xbmcplugin.setResolvedUrl(handle, True, li)
        else:
            xbmc.Player().play(item=url, listitem=li)
    else:
        control.infoDialog(lang.id('no_stream_available'), iconimage='INFO')
        
def tester(url):
    link = resolve_url(url)
    if link:
        url = link
    return url