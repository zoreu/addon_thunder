# -*- coding: utf-8 -*-
import six
from kodi_six import xbmc, xbmcvfs, xbmcgui, xbmcplugin, xbmcaddon
from resources.lib import control, navigator
import re
import sys
import os
handle = int(sys.argv[1])
version = '20.03.2022'

def update():
    url = 'https://raw.githubusercontent.com/zoreu/addon_thunder/main/update.txt'
    data = navigator.open_url(url)
    match = re.compile(r'id="(.*?)".+?rl="(.*?)"',re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    if match:
        for id, url in match:
            try:
                name = id.encode('utf-8', 'ignore')
            except:
                pass
            control.item({'name': name, 'action': 'install', 'addon_id': id, 'url': url, 'mediatype': 'video', 'iconimage': ''})
        xbmcplugin.endOfDirectory(handle)
        
def auto_update():
    try:
        url_version = 'https://raw.githubusercontent.com/zoreu/addon_thunder/main/version.txt'
        ver = navigator.open_url(url_version)
        try:
            ver = ver.replace('\n', '').replace('\r', '').replace(' ', '')
        except:
            pass
        if ver != version and ver !='' and ver !=None and ver !='none':
            url_update = 'https://raw.githubusercontent.com/zoreu/addon_thunder/main/update.txt'
            data = navigator.open_url(url_update)
            match = re.compile(r'id="(.*?)".+?rl="(.*?)"',re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
            if match:
                for id, url in match:
                    install(id,url)
                control.infoDialog('Auto update completed', iconimage='INFO')
    except:
        pass                   
        
def install(id,url):
    special_dir = 'special://home/addons/'+id
    special_packages = 'special://home/addons/packages'
    if six.PY3:
        directory = xbmcvfs.translatePath(special_dir)
        packages = xbmcvfs.translatePath(special_packages)
    else:
        directory = xbmc.translatePath(special_dir)
        packages = xbmc.translatePath(special_packages)        
    if os.path.exists(directory):
        try:
            from resources.lib import downloader, extract
            import ntpath
            filename = ntpath.basename(url)
            dest=os.path.join(packages, filename)
            dp = xbmcgui.DialogProgress()
            if six.PY3:
                dp.create('Downloading '+id+'...','Please wait...')
            else:
                dp.create('Downloading '+id+'...','Please wait...', '', '')
            downloader.download(url,id,dest,dp=dp)
            zip_file = dest
            extract_folder = directory
            if six.PY3:
                dp.create('Extracting '+id+'...','Please wait...')
            else:
                dp.create('Extracting '+id+'...','Please wait...', '', '')
            dp.update(0)
            extract.all(zip_file,extract_folder, dp=dp)
            try:
                os.remove(zip_file)
            except:
                pass
            control.infoDialog('Update completed', iconimage='INFO')
        except:
            control.infoDialog('Error', iconimage='WARNING')